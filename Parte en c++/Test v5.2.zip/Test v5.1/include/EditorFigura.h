#ifndef EDITORFIGURA_H
#define EDITORFIGURA_H
#include "Punto.h"
class EditorFigura
{
    public:
        EditorFigura()=default;
        virtual double calcularArea(){};
    protected:

    private:
};

#endif // EDITORFIGURA_H
