#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "Punto.h"
#include <QGraphicsView>
#include <QGraphicsScene>
#include <QColorDialog>
#include <QDebug>

//Metodo de convertir el string en un punto


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_actionArea_triggered()
{

}

void MainWindow::on_actionFondo_triggered()
{
    //QColor colorFondo;
    //colorFondo = QColorDialog::getColor(Qt::white,this);
    //ui->textEdit->setPalette(QPalette(colorFondo));
}

void MainWindow::deTextoALista(const QString & textocrudo)
{
    int i=0;
    while (i<textocrudo.size())
    {
        int cont= 0;
        while ((textocrudo.at(i)!="(") && (i<textocrudo.size()))
            i++;
        i++;
        while ((textocrudo.at(i)!=",") && (i<textocrudo.size()))
        {
            cont++;
            i++;
        }
        QStringRef subStringx(&textocrudo, i-cont, cont);
        double x = subStringx.toDouble();

        i++;
        cont= 0;
        while ((textocrudo.at(i)!=")") && (i<textocrudo.size()))
        {
            cont++;
            i++;
        }
        QStringRef subStringy(&textocrudo, i-cont, cont);
        double y = subStringy.toDouble();
        i+=2;
        Punto aux(x*100,y*100);
        listaPuntos.push_back(aux);
    }
    if (listaPuntos.isEmpty())
        qDebug() << "Ingrese un punto valido (por ejemplo (5,2))";
}

void MainWindow::on_buttonAgregar_clicked()
{
    QString textocrudo = ui->textPunto->text();
    deTextoALista(textocrudo);
    int i=0;
    while (i<listaPuntos.size())
    {
        ui->listPunto->addItem("(" + QString::number(listaPuntos.at(i).getX()/100) + ", " + QString::number(listaPuntos.at(i).getY()/100) + ")");
        qDebug() << "(" << listaPuntos.at(i).getX()/100 << ", " << listaPuntos.at(i).getY()/100 << ")";
        i++;
    }
    //(8,4),(8,5),(7,5),(7,4)
    ui->textPunto->clear();
}

void MainWindow::on_buttonEliminar_clicked()
{
    QModelIndex i=ui->listPunto->currentIndex();
    int j=i.row();
    int aux=0;
    listaPuntos.removeAt(j);
    while (aux<listaPuntos.size())
    {
        qDebug() << "(" << listaPuntos.at(aux).getX()/100 << ", " << listaPuntos.at(aux).getY()/100 << ")";
        aux++;
    }
    qDebug() << "";
    delete ui->listPunto->currentItem();
}

void MainWindow::on_buttonDibujar_clicked()
{

}

Punto MainWindow::promedio()
{
    double x=0, y=0;
    for (int i=0; i< listaPuntos.size(); i++)
    {
        x+=listaPuntos[i].getX();
        y+=listaPuntos[i].getY();
    }
    int size=listaPuntos.size();
    Punto aux(x/size,y/size);
    return aux;
}

void MainWindow::on_buttonGraficar_clicked()
{
    double radio= 5;

    // Creo una escena
    QGraphicsScene * scene = new QGraphicsScene();
    int size = listaPuntos.size();
    ui->graphicsView->setScene(scene);

    for(int i = 0; i< size; i++)
    {
        //Pongo los puntos del poligono como circulos en la escena
        scene->addEllipse(listaPuntos[i].getX()-radio/2, listaPuntos[i].getY()-radio/2, radio, radio);
        //Agrego lineas entre cada par de puntos
        if (i<size-1)
            scene->addLine(listaPuntos[i].getX(), listaPuntos[i].getY(), listaPuntos[i+1].getX(), listaPuntos[i+1].getY());
    }
    scene->addLine(listaPuntos[size-1].getX(), listaPuntos[size-1].getY(), listaPuntos[0].getX(), listaPuntos[0].getY());

    //Calculo el promedio de los puntos, y creo un punto donde deberia estar el centro
    Punto aux(promedio());
    scene->addEllipse(aux.getX()-radio/2, aux.getY()-radio/2, radio, radio);

    //Muestro la escena en la vista
    ui->graphicsView->show();
}
