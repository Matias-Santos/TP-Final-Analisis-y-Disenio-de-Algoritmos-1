#ifndef MAINWINDOW_H
#define MAINWINDOW_H
#include "Punto.h"
#include <QMainWindow>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
private:
    QList<Punto> listaPuntos;

private slots:
    void on_actionArea_triggered();

    void on_actionFondo_triggered();

    void on_buttonAgregar_clicked();

    void on_buttonEliminar_clicked();
    void deTextoALista(const QString & textocrudo);
private:
    Ui::MainWindow *ui;
};
#endif // MAINWINDOW_H
