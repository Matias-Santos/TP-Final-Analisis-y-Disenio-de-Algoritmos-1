#include "ventanacolores.h"
#include "ui_ventanacolores.h"

VentanaColores::VentanaColores(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::VentanaColores)
{
    ui->setupUi(this);
}

VentanaColores::~VentanaColores()
{
    delete ui;
}
