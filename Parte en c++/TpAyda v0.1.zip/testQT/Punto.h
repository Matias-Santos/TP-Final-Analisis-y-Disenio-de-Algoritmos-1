#ifndef PUNTO_H
#define PUNTO_H


class Punto
{
    public:

        Punto(){};
        Punto(const Punto & aux);
        Punto(double x, double y);
        void setX(double x);
        void setY(double y);
        double getX() const;
        double getY() const;
        void copiarPunto(Punto aux);
        double distancia(Punto aux);
        bool operator==(Punto aux);
        bool operator!=(Punto aux);
        double productoCruzado(Punto aux);
    private:
        double x;
        double y;
};

#endif // PUNTO_H
