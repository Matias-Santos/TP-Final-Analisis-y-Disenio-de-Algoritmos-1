#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QColorDialog>
#include "Punto.h"
#include <QDebug>

//Metodo de convertir el stirng en un punto


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_actionArea_triggered()
{

}

void MainWindow::on_actionFondo_triggered()
{
    //QColor colorFondo;
    //colorFondo = QColorDialog::getColor(Qt::white,this);
    //ui->textEdit->setPalette(QPalette(colorFondo));
}

void MainWindow::deTextoALista(const QString & textocrudo)
{
    int i=0;
    while (i<textocrudo.size())
    {
        i++;
        int cont= 0;
        while (textocrudo.at(i)!=",")
        {
            cont++;
            i++;
        }
        QStringRef subStringx(&textocrudo, i-cont, cont);
        double x = subStringx.toDouble();

        i++;
        cont= 0;
        while (textocrudo.at(i)!=")")
        {
            cont++;
            i++;
        }
        QStringRef subStringy(&textocrudo, i-cont, cont);
        double y = subStringy.toDouble();
        i+=2;

        Punto aux(x,y);
        listaPuntos.push_back(aux);
    }
}

void MainWindow::on_buttonAgregar_clicked()
{
    QString textocrudo = ui->textPunto->text();
    deTextoALista(textocrudo);
    int i=0;
    while (i<listaPuntos.size())
    {
        ui->listPunto->addItem("(" + QString::number(listaPuntos.at(i).getX()) + ", " + QString::number(listaPuntos.at(i).getY()) + ")");
        qDebug() << "(" << listaPuntos.at(i).getX() << ", " << listaPuntos.at(i).getY() << ")";
        i++;
    }
    //(8,4),(8,5),(7,5),(7,4)
}

void MainWindow::on_buttonEliminar_clicked()
{

}
