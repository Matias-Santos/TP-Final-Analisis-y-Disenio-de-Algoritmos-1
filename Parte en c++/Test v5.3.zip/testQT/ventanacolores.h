#ifndef VENTANACOLORES_H
#define VENTANACOLORES_H

#include <QDialog>

namespace Ui {
class VentanaColores;
}

class VentanaColores : public QDialog
{
    Q_OBJECT

public:
    explicit VentanaColores(QWidget *parent = nullptr);
    ~VentanaColores();

private:
    Ui::VentanaColores *ui;
};

#endif // VENTANACOLORES_H
