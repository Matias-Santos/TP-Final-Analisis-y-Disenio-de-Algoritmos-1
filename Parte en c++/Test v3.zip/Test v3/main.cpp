#include <iostream>
#include "Punto.h"
#include "Figura2D.h"
#include "Triangulo.h"
#include <cmath>
#include "Rectangulo.h"
#include "Cuadrado.h"
#include "Circulo.h"
#include "Segmento.h"
#include "Poligono.h"
using namespace std;

double calcular_area(list<Punto> listapuntos)
{
    list<Punto> :: iterator it= listapuntos.begin();
    double area=0;
    Punto aux=*it;
    Punto a=*it;
    while(it!=listapuntos.end())
    {
        it++;
        Punto b=*it;
        area= area + (0.5 * a.productoCruzado(b));
        a=*it;
    }
    area= area + (0.5 * a.productoCruzado(aux));
    if (area<0)
        area=area*(-1);
    return area;
}
double calcularArea(list<Punto> p)
{
    //metodo de gauss
    std::list<Punto>::iterator itp=p.begin();
    double area=0.0;
    Punto inicial=*itp;
    Punto ultimo;
    while(itp != p.end())
    {
        Punto aux=*itp;
        itp++;
        ultimo=*itp;
        area+= ((aux.productoCruzado(ultimo))/2);
        cout<<"area while:: " << area << endl;
    }
    area+= ((ultimo.productoCruzado(inicial))/2);
    cout<<"area fuera del while:: " << area << endl;
    if(area < 0)
        area=area*(-1);
    return area;
}
void imprimir(list<Punto> listapuntos)
{
    list<Punto>::iterator it=listapuntos.begin();
    while (it!=listapuntos.end())
    {
        cout << "(" << it->getX() << ", " << it->getY() << ")" << endl;
        it++;
    }
}
int main()
{
    Punto A(10,1);
    Punto B(12,12);
    Punto C(15,15);
    Punto D(13,8);
    Figura2D * figuraC= new Cuadrado(A,B,C,D);
    Figura2D * figuraT= new Triangulo(A,B,C);
    cout<<"Area del triangulo: " << figuraT->calcularArea()<<endl;
    cout<<"Area del cuadrado: "<< figuraC->calcularArea()<< " esta bien que de cero porque no es un cuadrado "<<endl;
    Punto E(1,1);
    Punto F(2,1);
    Punto G(1,2);
    Punto H(2,2);
    figuraC= new Cuadrado(E,F,G,H);
    cout<<"Area del cuadrado: "<< figuraC->calcularArea()<<endl;
    double aux=1;
    Figura2D * figuraCi= new Circulo(E,aux);
    cout<<"Area del circulo: "<< figuraCi->calcularArea()<<endl;
    Segmento seg(B,C);
    cout<< "longitud del segmento B-C: "<< seg.longitud()<<endl;
    cout<< "producto cruzado entre E y H : " << E.productoCruzado(H)<< endl;
    Punto polA(0,0);
    Punto polB(0,5);
    Punto polC(5,5);
    Punto polD(5,0);
    list<Punto> auxp;
    auxp.push_back(polA);
    auxp.push_back(polB);
    auxp.push_back(polC);
    auxp.push_back(polD);
    Poligono p(auxp);
    //cout<< "Area del poligono es de: " <<calcularArea(auxp) <<endl;
    //cout<< "Area del poligono es de: " <<calcular_area(auxp) <<endl;
    cout<< "Area del poligono es de: " <<p.calcularArea()<<endl;
    imprimir(p.devolverCopia());
    cout<< p.sizePoligono()<<endl;
    cout<< "Perimetro: " << p.calcularPerimetro() << endl;
    cout<< "Dist entre A y B: " << polA.distancia(polB) << endl;
    cout<< "Dist entre B y C: " << polB.distancia(polC) << endl;
    cout<< "Dist entre C y D: " << polC.distancia(polD) << endl;
    cout<< "Dist entre D y A: " << polD.distancia(polA) << endl;
    return 0;
}
