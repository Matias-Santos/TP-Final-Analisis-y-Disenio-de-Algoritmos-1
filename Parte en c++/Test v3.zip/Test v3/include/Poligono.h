#ifndef POLIGONO_H
#define POLIGONO_H
#include <list>
#include <iterator>
#include <iostream>
class Poligono: public Figura2D
{
private:
    std::list<Punto> p;

    void agregar(Punto aAgregar)
    {
        p.push_back(aAgregar);
    }
public:
    Poligono(std::list<Punto> aux): Figura2D()
    {
        std::list<Punto>:: iterator itp= aux.begin();
        for(itp=aux.begin(); itp!=aux.end(); itp++)
            p.push_back(*itp);
    }

    void agregarPunto(Punto aAgregar)
    {
        agregar(aAgregar);
    }

    double calcularArea()
    {
        //metodo de gauss
        std::list<Punto>::iterator itp=p.begin();
        double area=0.0;
        Punto inicial=*itp;
        Punto ultimo;
        for(int i=0; i<p.size()-1; i++)
        {
            Punto aux=*itp;
            itp++;
            ultimo=*itp;
            area= area + (0.5*(aux.productoCruzado(ultimo)));
        }
        area=area + ((ultimo.productoCruzado(inicial))/2);
        if(area < 0)
            area=area*(-1);
        return area;
    }

    int sizePoligono()
    {
        return p.size();
    }

    std::list<Punto> devolverCopia()
    {

        std::list<Punto>:: iterator itp=p.begin();
        std::list<Punto> copia;
        while(itp!= p.end())
        {
            copia.push_back(*itp);
            itp++;
        }
        return copia;
    }
    double calcularPerimetro()
    {
        double suma=0;
        std::list<Punto>:: iterator itp=p.begin();
        Punto inic= *itp;
        for (int i=0; i<p.size()-1; i++)
        {
            Punto a=*itp;
            itp++;
            Punto b=*itp;
            suma+=a.distancia(b);
            std::cout << "suma: " << suma << std::endl;
        }
        //Hago el caso especial que une al ultimo punto de la lista con el primero, afuera del for
        Punto fin = *itp;
        suma+=inic.distancia(fin);
        return suma;
    }

    virtual ~Poligono()
    {
        p.clear();
    }

protected:

};

#endif // POLIGONO_H
