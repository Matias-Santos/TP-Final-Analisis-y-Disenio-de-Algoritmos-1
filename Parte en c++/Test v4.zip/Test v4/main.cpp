#include <iostream>
#include "Punto.h"
#include "Figura2D.h"
#include "Triangulo.h"
#include <cmath>
#include "Rectangulo.h"
#include "Cuadrado.h"
#include "Circulo.h"
#include "Segmento.h"
#include <iomanip>
#include "Poligono.h"
using namespace std;

//------------------------------- Imprimir lista de puntos --------------------------------------------------

void imprimirPuntos(list<Punto> listapuntos)
{
    list<Punto>::iterator it=listapuntos.begin();
    while (it!=listapuntos.end())
    {
        cout << "(" << it->getX() << ", " << it->getY() << ")" << endl;
        it++;
    }
}

//----------------------------Crear matriz---------------------------------------------------------

void crearMatriz(double ** & matriz,const int & columna,const int & fila)
{
    matriz = new double*[fila];
    for (int f = 0; f < fila; f++)
        matriz[f] = new double[columna];
}

//----------------------------Cargar Matriz vacia-------------------------

void cargarMatriz(double ** & matriz,const int & columna,const int & fila)
{
    for(int i=0; i<fila; i++)
        for(int j=0; j<columna; j++)
            if(i<=3)
                matriz[i][j]= 0.0 ;
            else
                matriz[i][j]= -1;
}

//-------------------------------Imprimir matriz--------------------------------------------------

void mostrarMatriz(double **matriz, int columna, int fila)
{
    for (int f = 0; f < fila; f++)
    {
        for (int c = 0; c < columna; c++)
            cout << setw(4) << matriz[f][c] << "  ";
        cout << "\n";
    }
    cout << endl;
}

//------------------------------- Triangulacion --------------------------------------------------
/*void triangulacionv2(Punto p[],double **&matriz,int tam)
{
    if(tam<4)
        return 0;
    else
        for(int s=4;s<=tam;s++)
            for(int i=0; i<=tam; i++)
                for(int k=1;k<=s-2;k++)
                {
                    double aux=
                }
}*/
double minimo(double a, double b)
{
    if((a>0)&&(b>0)&&(a>=b))
        return b;
    else
    {
        if(a<=0)
            return b;
        else
            if(b>=0)
                return a;
    }
}

double devuelvePositivo(double a)
{
    if(a==-1)
        return 0;
    else
        return a;
}
double triangulacion(Punto p[], double **&matriz)
{
    int tam = 7;
    if(tam<4)
        return 0;
    else
    {
        for(int s=4; s<=tam; s++)
            for(int i=0; i<=tam; i++)
                for(int k=1; k<=s-2; k++)
                {
                    Punto a,b,c;
                    a = p[i];
                    double valorMat1,valorMat2,aux=0;
                    if(i+k > tam-1)
                    {
                        b=p[i+k-tam];
                        valorMat1=(matriz[k+1][i]);
                        valorMat2=(matriz[s-k][i+k-tam]);
                    }
                    else
                    {
                        b=p[i+k];
                        valorMat1=(matriz[k+1][i]);
                        valorMat2=(matriz[s-k][i+k]);
                    }
                    if(i+s-1 > tam-1)
                         c=p[i+s-1-tam];
                    else
                         c=p[i+s-1];
                    if((i+1==i+k)||(i-1==i+k))
                        aux=valorMat1+valorMat2+b.distancia(c);
                    else
                        if(((i+k+1)==(i+s-1))||((i+k-1)==(i+s-1)))
                            aux=valorMat1+valorMat2+a.distancia(b);
                        else
                            aux=valorMat1+valorMat2+a.distancia(b)+b.distancia(c);
                    if((matriz[s][i]>= aux)||(matriz[s][i]==-1))
                        matriz[s][i]=aux;
                }
        mostrarMatriz(matriz,tam,tam+1);
        return matriz[7][0];
    }
}
int main()
{
    Punto v0(0,10);
    Punto v1(0,20);
    Punto v2(8,26);
    Punto v3(15,26);
    Punto v4(27,21);
    Punto v5(22,12);
    Punto v6(10,0);
    Punto arrP[7];
    arrP[0]=v0;
    arrP[1]=v1;
    arrP[2]=v2;
    arrP[3]=v3;
    arrP[4]=v4;
    arrP[5]=v5;
    arrP[6]=v6;
    list<Punto> lisPuntos;
    lisPuntos.push_back(v0);
    lisPuntos.push_back(v1);
    lisPuntos.push_back(v2);
    lisPuntos.push_back(v3);
    lisPuntos.push_back(v4);
    lisPuntos.push_back(v5);
    lisPuntos.push_back(v6);
    Poligono * p=new Poligono(lisPuntos);
    double **matrizCosto=0;
    int i=lisPuntos.size()+1;
    int f=i+1;
    crearMatriz(matrizCosto,f,i);
    cargarMatriz(matrizCosto,i,i);
    //mostrarMatriz(matrizCosto,f,i);
    Punto auxaaa=arrP[2];
    Punto auxxxxx=arrP[4];
    //cout<< "costo v3 --> v5 : "<< v3.distancia(v5)<<endl;
    //cout<< "costo v0 --> v1 : "<< v0.distancia(v1)<<endl;
    //cout<< "costo v1 --> v3 : "<< v1.distancia(v3)<<endl;
    //cout<< "costo v2 --> v4 : "<< auxaaa.distancia(auxxxxx)<<endl;
    //cout<< "costo de la triangulacion minima:  " << triangulacion(arrP,matrizCosto)<< endl;
    cout<< "costo de la triangulacion minima:  " << p->triangulacion()<< endl;
    Punto * auxP;
    //p->devuelveCopiaEnArreglo(auxP);
    for(int i=0; i<p->sizePoligono();i++)
        {
            cout<<" ( "<<auxP[i].getX()<<" , "<<auxP[i].getY() << " ) "<< endl;
        }
    return 0;
}
