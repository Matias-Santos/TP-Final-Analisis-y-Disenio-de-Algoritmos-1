#ifndef POLIGONO_H
#define POLIGONO_H
#include <vector>
#include <list>
#include <iterator>
#include <iostream>
using namespace std;

class Poligono: public Figura2D
{
private:
    list<Punto> p;
    void agregar(Punto aAgregar)
    {
        p.push_back(aAgregar);
    }

public:
    Poligono(list<Punto> aux): Figura2D()
    {
        list<Punto>:: iterator itp= aux.begin();
        for(itp=aux.begin(); itp!=aux.end(); itp++)
            p.push_back(*itp);
    }

    void agregarPunto(Punto aAgregar)
    {
        agregar(aAgregar);
    }

    vector<Punto> devuelveCopiaEnArreglo()
    {
        vector<Punto> vecP;
        list<Punto>::iterator itp= p.begin();
        for(int i=0;i<=this->sizePoligono();i++)
        {
            Punto a=*itp;
            vecP.push_back(a);
            itp++;
        }
        return vecP;
    }

    double calcularArea()
    {
        double area=0;
        list<Punto>:: iterator itp=p.begin();
        Punto inic= *itp;
        for (int i=0; i<p.size()-1; i++)
        {
            Punto a=*itp;
            itp++;
            Punto b=*itp;
            area+=a.distancia(b);
        }
        Punto fin = *itp;
        area+=inic.distancia(fin);
        if(area < 0)
            return area*(-0.5);
        else
            return area*(0.5);
    }

    int sizePoligono()
    {
        return p.size();
    }

    list<Punto> devolverCopiaEnLista()
    {

        list<Punto>:: iterator itp=p.begin();
        list<Punto> copia;
        while(itp!= p.end())
        {
            copia.push_back(*itp);
            itp++;
        }
        return copia;
    }

    double calcularPerimetro()
    {
        double perimetro=0;
        list<Punto>:: iterator itp=p.begin();
        Punto inic= *itp;
        for (int i=0; i<p.size()-1; i++)
        {
            Punto a=*itp;
            itp++;
            Punto b=*itp;
            perimetro+=a.distancia(b);
        }
        Punto fin = *itp;
        perimetro+=inic.distancia(fin);
        return perimetro;
    }

    virtual ~Poligono()
    {
        p.clear();
    }

    double triangulacion()
    {
        int n=this->sizePoligono();
        if(n<4)
            return 0;

        double mat[n][n];
        for(int f=0;f<=n;f++)
            for(int c=0;c<=n;c++)
                mat[f][c]=0;
        cout<<"cargo matriz"<< endl;
        vector<Punto> vecP=this->devuelveCopiaEnArreglo();
        cout<< "cargo arreglo " << endl;
        for(int s=4; s<=n; s++)
            for(int i=0; i<=n; i++)
                for(int k=1; k<=s-2; k++)
                {
                    Punto a,b,c;
                    a = vecP.at(i);
                    double valorMat1,valorMat2,aux=0;
                    if(i+k > n-1)
                    {
                        b=vecP.at(i+k-n);
                        valorMat1=(mat[k+1][i]);
                        valorMat2=(mat[s-k][i+k-n]);
                    }
                    else
                    {
                        b=vecP.at(i+k);
                        valorMat1=(mat[k+1][i]);
                        valorMat2=(mat[s-k][i+k]);
                    }
                    if(i+s-1 > n-1)
                         c=vecP.at(i+s-1-n);
                    else
                         c=vecP.at(i+s-1);
                    if((i+1==i+k)||(i-1==i+k))
                        aux=valorMat1+valorMat2+b.distancia(c);
                    else
                        if(((i+k+1)==(i+s-1))||((i+k-1)==(i+s-1)))
                            aux=valorMat1+valorMat2+a.distancia(b);
                        else
                            aux=valorMat1+valorMat2+a.distancia(b)+b.distancia(c);
                    if((mat[s][i]>= aux)||(mat[s][i]==-1))
                        mat[s][i]=aux;
                }
        std::cout<< "termino" << endl;
        for(int i=0;i<=n;i++)
        {
            for(int j=0;j<=n;j++)
                cout<< mat[i][j]<<"      ";
            cout<< "" <<endl;
        }
        return mat[n][0];
    }
};

#endif // POLIGONO_H
