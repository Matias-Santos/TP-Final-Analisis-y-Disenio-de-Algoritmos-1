#include "ventanatriangulacion.h"
#include "ui_ventanatriangulacion.h"
#include <QtDebug>

ventanaTriangulacion::ventanaTriangulacion(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::ventanaTriangulacion)
{
    ui->setupUi(this);
}

ventanaTriangulacion::~ventanaTriangulacion()
{
    delete ui;
}

void ventanaTriangulacion::mostrarMatrizCosto(double ** & matriz,int n){

    qDebug() << "entro a mostrar" ;
    //ui->MatrizCosto->setColumnCount(n);
    //ui->MatrizCosto->insertRow(n-2);
    qDebug() << "llego hasta aca" ;
    /*
    for (int f = n-1; f > 2; f--)
    {
        for(int c=0;c<n;c++)
            {
                //qDebug() << "c: " << c << " f: " << f;
                //qDebug() << matriz[f][c] ;
                double aux= matriz[f][c];
                //qDebug() << aux ;
                QString valor= QString::number(aux);
                //qDebug() << valor;
                //QTableWidgetItem val(valor);
                //ui->MatrizCosto->setItem(f,c,&val);
                ui->MatrizCosto->setItem(f,c,new QTableWidgetItem(valor));
                //ui->MatrizCosto->item(f,c)->setText(valor);
            }
        //ui->MatrizCosto->insertRow(ui->MatrizCosto->rowCount()-1);
        qDebug()<< "agrega una fila";
    }
    qDebug() << "salio de mostrar" ;
    */
    for(int f=n-1;f > 2;f--)
        ui->MatrizCosto->insertRow(f);
    for(int c=0;c<n;c++)
        ui->MatrizCosto->insertColumn(c);
    for (int f = n-1; f > 2; f--)
        for(int c=0;c<n;c++)
        {
            double aux= matriz[f][c];
            QString valor= QString::number(aux);
            ui->MatrizCosto->setItem(f,c,new QTableWidgetItem(valor));
        }
 }
