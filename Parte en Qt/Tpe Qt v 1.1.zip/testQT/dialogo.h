#ifndef DIALOGO_H
#define DIALOGO_H

#include <QDialog>

namespace Ui {
class Dialogo;
}

class Dialogo : public QDialog
{
    Q_OBJECT

public:
    explicit Dialogo(QWidget *parent = nullptr);
    ~Dialogo();
    void cambiartexto(QString a);

private slots:
    void on_aceptarbutton_clicked();

private:
    Ui::Dialogo *ui;
};

#endif // DIALOGO_H
