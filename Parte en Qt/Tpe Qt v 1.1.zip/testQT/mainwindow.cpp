#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "Punto.h"
#include <QGraphicsView>
#include <QGraphicsScene>
#include <QColorDialog>
#include <QDebug>

//Metodo de convertir el string en un punto


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    //Crea una scena para ver el poligono
    scene = new QGraphicsScene();

    //color y grosor de las lineas del grafico
    penPol.setColor(Qt::black);
    penPol.setWidth(5);

    //crea una ventana para imprimir por pantalla los resultados de la matriz
    vTriangulacion = new ventanaTriangulacion(this);
    vTriangulacion->setWindowTitle("Calculo de la triangulacion");

    //Crea una ventana para imprimir por pantalla cuando ingresa un punto no valido
    ventanaError = new Dialogo(this);
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_actionArea_triggered()
{

}

void MainWindow::on_actionFondo_triggered()
{
    QString textEdit;
    QColor colorFondo;
    colorFondo = QColorDialog::getColor(Qt::white,this);
    penPol.setColor(colorFondo);
    graficar(penPol);
}

void MainWindow::on_actionTriangulacionminima_triggered()
{

    Poligono p(listaPuntos);
    double ** matrizCosto=0;
    double ** matrizK=0;
    p.triangulacion(matrizCosto,matrizK);
    qDebug()<<"costo de la triangulacion"<< p.triangulacion(matrizCosto,matrizK);
    qDebug()<< "calculo la triangulacion";
    qDebug()<< "tamaño de la matriz" << sizeof (matrizCosto);

    p.mostraraMatriz(matrizCosto,p.sizePoligono(),p.sizePoligono());
    vTriangulacion->mostrarMatrizCosto(matrizCosto,p.sizePoligono());
    vTriangulacion->show();
}


void MainWindow::deTextoALista(const QString & textocrudo)
{
    bool ok;
    int i=0;
    while (i<textocrudo.size())
    {
        int cont= 0;
        while ((textocrudo.at(i)!="(") && (i<textocrudo.size()))
            i++;
        i++;

        while ((textocrudo.at(i)!=",") && (i<textocrudo.size()))
        {
            cont++;
            i++;
        }
        QStringRef subStringx(&textocrudo, i-cont, cont);
        qDebug() << "te muestro el substrinxX: " << subStringx;
        double x = subStringx.toDouble(&ok);

        qDebug() << "te muestro lo que guardo en: " << x;
        if(!ok)
            x=INT_MAX;
        i++;
        cont= 0;

        while ((textocrudo.at(i)!=")") && (i<textocrudo.size()))
        {
            cont++;
            i++;
        }
        QStringRef subStringy(&textocrudo, i-cont, cont);
        qDebug() << "te muestro el substringy: " << subStringy;
        double y = subStringy.toDouble(&ok);
        if(!ok)
            y=INT_MAX;
        qDebug() << "te muestro lo que guardo en: " << y;
        i+=2;

        if((x!=INT_MAX)&&(y!=INT_MIN))
        {
            Punto aux(x*100,y*100);
            listaPuntos.push_back(aux);
        }

    }
    if (listaPuntos.isEmpty())
    {
        ventanaError->show();
        ventanaError->cambiartexto("Ingrese un punto valido (por ejemplo (5,2))");
    }
    qDebug() << "Ingrese un punto valido (por ejemplo (5,2))";
}

void MainWindow::on_buttonAgregar_clicked()
{
    QString textocrudo = ui->textPunto->text();
    deTextoALista(textocrudo);
    int i=0;
    ui->listPunto->clear();
    while (i<listaPuntos.size())
    {
        ui->listPunto->addItem("(" + QString::number(listaPuntos.at(i).getX()/100) + ", " + QString::number(listaPuntos.at(i).getY()/100) + ")");
        qDebug() << "(" << listaPuntos.at(i).getX()/100 << ", " << listaPuntos.at(i).getY()/100 << ")";
        i++;
    }
    //(7.5,3.5),(8,4),(8,5),(7,5),(7,4)
    ui->textPunto->clear();
}

void MainWindow::on_buttonEliminar_clicked()
{
    QModelIndex i=ui->listPunto->currentIndex();
    int j=i.row();
    int aux=0;
    listaPuntos.removeAt(j);
    while (aux<listaPuntos.size())
    {
        qDebug() << "(" << listaPuntos.at(aux).getX()/100 << ", " << listaPuntos.at(aux).getY()/100 << ")";
        aux++;
    }
    qDebug() << "";
    delete ui->listPunto->currentItem();
}

Punto MainWindow::promedio()
{
    double x=0, y=0;
    for (int i=0; i< listaPuntos.size(); i++)
    {
        x+=listaPuntos[i].getX();
        y+=listaPuntos[i].getY();
    }
    int size=listaPuntos.size();
    Punto aux(x/size,y/size);
    return aux;
}

void MainWindow::graficar(QPen penPol)
{
    double radio= 5;
    int size = listaPuntos.size();
    scene->clear();
    ui->graphicsView->setScene(scene);
    if (size>2)
    {
        for(int i = 0; i< size; i++)
        {
            //Pongo los puntos del poligono como circulos en la escena
            //scene->addText();
            //scene->addText(listaPuntos[i].getX()-radio/2, listaPuntos[i].getY()-radio/2, radio, radio);
            scene->addEllipse(listaPuntos[i].getX()-radio/2, listaPuntos[i].getY()-radio/2, radio, radio);
            //Agrego lineas entre cada par de puntos
            if (i<size-1)
                scene->addLine(listaPuntos[i].getX(), listaPuntos[i].getY(), listaPuntos[i+1].getX(), listaPuntos[i+1].getY(), penPol);
        }
        scene->addLine(listaPuntos[size-1].getX(), listaPuntos[size-1].getY(), listaPuntos[0].getX(), listaPuntos[0].getY(), penPol);

        //Calculo el promedio de los puntos, y creo un punto donde deberia estar el centro
        Punto aux(promedio());
        scene->addEllipse(aux.getX()-radio/2, aux.getY()-radio/2, radio, radio);

        //Muestro la escena en la vista
        ui->graphicsView->show();
    }
    else
    {
        ventanaError->cambiartexto("No hay suficientes puntos para formar un poligono");
        ventanaError->show();
    }
}

void MainWindow::on_buttonGraficar_clicked()
{
    graficar(penPol);
    ui->graphicsView->show();
}
