#ifndef VENTANATRIANGULACION_H
#define VENTANATRIANGULACION_H

#include <QDialog>

namespace Ui {
class ventanaTriangulacion;
}

class ventanaTriangulacion : public QDialog
{
    Q_OBJECT

public:
    explicit ventanaTriangulacion(QWidget *parent = nullptr);
    ~ventanaTriangulacion();
    void mostrarMatrizCosto(double ** & matriz,int n);
private:
    Ui::ventanaTriangulacion *ui;
};

#endif // VENTANATRIANGULACION_H
