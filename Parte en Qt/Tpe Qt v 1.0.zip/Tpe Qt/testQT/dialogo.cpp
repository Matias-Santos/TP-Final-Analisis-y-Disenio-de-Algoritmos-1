#include "dialogo.h"
#include "ui_dialogo.h"

Dialogo::Dialogo(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Dialogo)
{
    ui->setupUi(this);
}

Dialogo::~Dialogo()
{
    delete ui;
}

void Dialogo::cambiartexto(QString a)
{
    ui->label->setText(a);
}

void Dialogo::on_aceptarbutton_clicked()
{
    this->setHidden(true);
}
