#include "poligono.h"
#include <iterator>
#include <QDebug>

//---------------------Metodos privados-------------------
void Poligono::agregarPrivado(Punto aAgregar)
{
    pol.push_back(aAgregar);
}

//Metodo para crear la matriz O(n) siendo n la cantidad de filas
void Poligono::crearMatriz(double ** & matriz, int columna, int fila)
{
    matriz = new double*[fila];
    for (int f = 0; f <= fila; f++)
        matriz[f] = new double[columna];
}

//Metodo para preCargar la matriz O(n^m) siendo n la cantidad de filas y m la cantidad de columnas
void Poligono::preCargaMatriz(double ** & matriz, int columna, int fila)
{
    for(int i=0; i<=fila; i++)
        for(int j=0; j<columna; j++)
                matriz[i][j]= 0;
}

void Poligono::mostraraMatriz(double **matriz, int columna, int fila)
{
    for (int f = fila-1; f > 2; f--)
    {
        for (int c = 0; c < columna; c++)
        {
            double aux=0.0;
            aux=matriz[f][c];
            qDebug() << aux;
        }
        qDebug() << "\n";
    }
    qDebug() <<"";
}

//---------------------Metodos publicos--------------------

//Metodo constructor de la clase O(n)
Poligono::Poligono(QList<Punto> listpunto)
{
    QList<Punto>::iterator i;
    for(i=listpunto.begin();i< listpunto.end();i++)
        pol.push_back(*i);
}

//Metodo destructor de la clase O(n)
Poligono::~Poligono()
{
    pol.clear();
}

//Metodo agregar publico que se encarga de llamar al privado O(1)
void Poligono::agregar(Punto aAgregar)
{
    agregarPrivado(aAgregar);
}

//Metodo que retorna el tamaño del poligono O(1)
int Poligono::sizePoligono()
{
    return pol.size();
}

//Metodo que retorna la copia en un vector
QVector<Punto> Poligono::devuelveCopiaEnVector()
{
    QVector<Punto> vecpol;
    QList<Punto>::Iterator it;
    for(it=pol.begin();it<pol.end();it++)
    {
        vecpol.push_back(*it);
    }
    return vecpol;
}

//Metodo para calcular el area de un poligono O(n)
double Poligono::calcularArea()
{
    double area=0.0;
    QList<Punto>::Iterator itp;
    itp=pol.begin();
    Punto inic= *itp;
    for (int i=0; i<pol.size()-1; i++)
    {
        Punto a=*itp;
        itp++;
        Punto b=*itp;
        area+=a.distancia(b);
    }
    Punto fin = *itp;
    area+=inic.distancia(fin);
    if(area < 0)
        return area*(-0.5);
    else
        return area*(0.5);
}

//Metodo para calcular el perimetro de un poligono O(n)
double Poligono::calcularPerimetro()
{
    double perimetro=0.0;
    QList<Punto>::Iterator itp=pol.begin();
    Punto inic= *itp;
    for (int i=0; i<pol.size()-1; i++)
    {
        Punto a=*itp;
        itp++;
        Punto b=*itp;
        perimetro+=a.distancia(b);
    }
    Punto fin = *itp;
    perimetro+=inic.distancia(fin);
    return perimetro;
}

//Metodo para calcular la triangulacion O(n^3)
double Poligono::triangulacion()
{
    qDebug()<<"pol.size()" << pol.size() ;
    int tam = pol.size();
    if(tam<4)
        return 0;
    //Pasaje de lista a vector
    QVector<Punto> vecP=this->devuelveCopiaEnVector();

    //Inicializacion de la matriz
    double **matriz=0;
    double **matrizK=0;
    crearMatriz(matriz,tam,tam);
    preCargaMatriz(matriz,tam,tam);
    crearMatriz(matrizK,tam,tam);
    preCargaMatriz(matrizK,tam,tam);

    //Algoritmo
    for(int s=4; s<=tam; s++)
        for(int i=0; i<tam; i++)
            for(int k=1; k<=s-2; k++)
            {
                Punto a,b,c;
                a.copiarPunto(vecP.at(i));
                double valorMat1,valorMat2,aux=0;
                if(i+k > tam-1)
                {
                    b.copiarPunto(vecP.at(i+k-tam));
                    valorMat1=(matriz[k+1][i]);
                    valorMat2=(matriz[s-k][i+k-tam]);
                }
                else
                {
                    b.copiarPunto(vecP.at(i+k));
                    valorMat1=(matriz[k+1][i]);
                    valorMat2=(matriz[s-k][i+k]);
                }
                if(i+s-1 > tam-1)
                    c.copiarPunto(vecP.at(i+s-1-tam));
                else
                    c.copiarPunto(vecP.at(i+s-1));
                if ((i+1==i+k)||(i-1==i+k))
                    aux = valorMat1 + valorMat2 + b.distancia(c);
                else if(((i+k+1)==(i+s-1))||((i+k-1)==(i+s-1)))
                    aux = valorMat1 + valorMat2 + a.distancia(b);
                else
                    aux= valorMat1 + valorMat2 + a.distancia(b) + b.distancia(c);
                if((matriz[s][i]>= aux)||(matriz[s][i]==0))
                {
                    matriz[s][i]=aux;
                    matrizK[s][i]=k;
                }
            }
    mostraraMatriz(matriz,tam,tam);
    qDebug() <<"------------------------------------------------------------------";
    mostraraMatriz(matrizK,tam,tam);
    return matriz[tam][0];
}

Punto Poligono::calcularcentro()
{
    double xaux=0,yaux=0;
    QList<Punto>:: iterator it;
    Punto aux(0,0);
    for(it=pol.begin();it!=pol.end();it++)
    {
        aux=*it;
        xaux+=aux.getX();
        yaux+=aux.getY();
    }
    aux.setX(xaux/pol.size());
    aux.setY(yaux/pol.size());
    return aux;
}
