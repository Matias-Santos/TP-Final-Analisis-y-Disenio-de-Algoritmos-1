#include "mainwindow.h"
#include "Punto.h"
#include "poligono.h"
#include <QApplication>
#include <QDebug>
#include <QList>

using namespace std;

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    Punto x(-4,0);
    Punto y(5,0);

    /*
    Punto a0(85,25);
    Punto a1(29,70);
    Punto a2(26,106);
    Punto a3(22,171);
    Punto a4(12,348);
    Punto a5(16,375);
    Punto a6(27,430);
    Punto a7(47,441);
    Punto a8(117,444);
    Punto a9(303,435);
    Punto a10(333,424);
    Punto a11(371,396);
    Punto a12(393,346);
    Punto a13(404,312);
    Punto a14(409,262);
    Punto a15(415,197);
    Punto a16(418,143);
    Punto a17(411,105);
    Punto a18(390,51);
    Punto a19(375,26);
    Punto a20(310,13);
    Punto a21(234,9);
    Punto a22(200,8);
    QList<Punto> auxP;
    auxP.push_back(a0);
    auxP.push_back(a1);
    auxP.push_back(a2);
    auxP.push_back(a3);
    auxP.push_back(a4);
    auxP.push_back(a5);
    auxP.push_back(a6);
    auxP.push_back(a7);
    auxP.push_back(a8);
    auxP.push_back(a9);
    auxP.push_back(a10);
    auxP.push_back(a11);
    auxP.push_back(a12);
    auxP.push_back(a13);
    auxP.push_back(a14);
    auxP.push_back(a15);
    auxP.push_back(a16);
    auxP.push_back(a17);
    auxP.push_back(a18);
    auxP.push_back(a19);
    auxP.push_back(a20);
    auxP.push_back(a21);
    auxP.push_back(a22);
    */
    Punto v0(0,10);
    Punto v1(0,20);
    Punto v2(8,26);
    Punto v3(15,26);
    Punto v4(27,21);
    Punto v5(22,12);
    Punto v6(10,0);
    //(0,10) (0,20) (8,26) (15,26) (27,21) (22,12) (10,0)
    QList<Punto> lisPuntos;
    lisPuntos.push_back(v0);
    lisPuntos.push_back(v1);
    lisPuntos.push_back(v2);
    lisPuntos.push_back(v3);
    lisPuntos.push_back(v4);
    lisPuntos.push_back(v5);
    lisPuntos.push_back(v6);
    Poligono p(lisPuntos);

    double ** matrizCosto;
    double ** matrizK;
    //Poligono p2(auxP);
    //qDebug() << "costo de la triangulacion minima:  ";
    //qDebug()<< p.triangulacion(matrizCosto,matrizK);
    //qDebug() << "costo de la triangulacion minima:  " << p2->triangulacion();
    MainWindow w;
    // w.showMinimized();
    w.showNormal();
    //w.showFullScreen();
    //w.showMaximized();
    return a.exec();
}
