#include "ventanatriangulacion.h"
#include "ui_ventanatriangulacion.h"
#include <QtDebug>

ventanaTriangulacion::ventanaTriangulacion(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::ventanaTriangulacion)
{
    ui->setupUi(this);
}

ventanaTriangulacion::~ventanaTriangulacion()
{
    delete ui;
}

void ventanaTriangulacion::imprimeCosto(double aux)
{
   QString aux2("Costo minimo de la triangulacion: " + QString::number(aux));
   ui->costoMinimo->setText(aux2);
}

void ventanaTriangulacion::mostrarMatrizCosto(double ** & matriz,int n)
{
    ui->MatrizCosto->setColumnCount(n);
    ui->MatrizCosto->setRowCount(n-2);
    QStringList titulosCol;
    QStringList titulosFil;
    titulosCol<< "col 0" << "col 1" << "col 2" << "col 3" << "col 4" << "col 5" << "col 6" ;
    titulosFil<< "fil 7" << "fil 6" << "fil 5" << "fil 4" << "fil 3" ;//<< "fil 5" << "fil 6" ;
    ui->MatrizCosto->setHorizontalHeaderLabels(titulosCol);
    ui->MatrizCosto->setVerticalHeaderLabels(titulosFil);
    double aux= matriz[n][0]/100;
    QString valor= QString::number(aux);
    qDebug()<<"creo la matriz";

    QTableWidgetItem *item = new QTableWidgetItem(valor);
    item->setFlags(item->flags() ^ (Qt::ItemIsSelectable|Qt::ItemIsEditable));
    ui->MatrizCosto->setItem(0,0,item);

    int j=1;
    for (int f = n-1; f > 2; f--)
    {
        for(int c=0; c< n ; c++)
        {
            aux= matriz[f][c];
            QString valor= QString::number(aux);
            QTableWidgetItem *item = new QTableWidgetItem(valor);
            item->setFlags(item->flags() ^ (Qt::ItemIsSelectable|Qt::ItemIsEditable));
            ui->MatrizCosto->setItem(j,c,item);
        }
        j++;
   }
    QHeaderView * headerHorizontal= ui->MatrizCosto->horizontalHeader();
    QHeaderView * headerVertical= ui->MatrizCosto->verticalHeader();
    headerHorizontal->setSectionResizeMode(QHeaderView::Stretch);
    headerVertical->setSectionResizeMode(QHeaderView::Stretch);
}
void ventanaTriangulacion::mostrarMatrizK(double ** & matriz,int n)
{

    ui->MatrizK->setColumnCount(n);
    ui->MatrizK->setRowCount(n-2);
    QStringList titulosCol;
    QStringList titulosFil;
    titulosCol<< "col 0" << "col 1" << "col 2" << "col 3" << "col 4" << "col 5" << "col 6" ;
    titulosFil<< "fil 7" << "fil 6" << "fil 5" << "fil 4" << "fil 3" ;//<< "fil 5" << "fil 6" ;
    ui->MatrizK->setHorizontalHeaderLabels(titulosCol);
    ui->MatrizK->setVerticalHeaderLabels(titulosFil);
    double aux= matriz[n][0];
    QString valor= QString::number(aux);
    qDebug()<<"creo la matriz";


    QTableWidgetItem *item = new QTableWidgetItem(valor);
    item->setFlags(item->flags() ^ (Qt::ItemIsSelectable|Qt::ItemIsEditable));
    ui->MatrizK->setItem(0,0,item);

    int j=1;
    for (int f = n-1; f > 2; f--)
    {
        for(int c=0; c < n ; c++)
        {
            aux= matriz[f][c];
            QString valor= QString::number(aux);
            QTableWidgetItem *item = new QTableWidgetItem(valor);
            item->setFlags(item->flags() ^ (Qt::ItemIsSelectable|Qt::ItemIsEditable));
            ui->MatrizK->setItem(j,c,item);
        }
        j++;
    }
    QHeaderView * headerHorizontal= ui->MatrizK->horizontalHeader();
    QHeaderView * headerVertical= ui->MatrizK->verticalHeader();
    headerHorizontal->setSectionResizeMode(QHeaderView::Stretch);
    headerVertical->setSectionResizeMode(QHeaderView::Stretch);
}
