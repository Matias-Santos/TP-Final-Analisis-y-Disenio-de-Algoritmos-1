#ifndef MAINWINDOW_H
#define MAINWINDOW_H
#include <QMainWindow>
#include <QPen>
#include <QGraphicsScene>
#include "Punto.h"
#include "dialogo.h"
#include "ventanatriangulacion.h"
#include "poligono.h"
#include "ventanaborde.h"

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    Dialogo * ventanaError;
    ventanaTriangulacion * vTriangulacion;
    ~MainWindow();
private:
    QPen penPol;
    QList<Punto> listaPoligono;
    QList<Punto> listaGrafico;
    VentanaBorde * vGrosor;


private slots:
    void on_actionArea_triggered();

    void on_actionFondo_triggered();

    void cargarEnListWidget();

    void on_buttonAgregar_clicked();

    void on_buttonEliminar_clicked();

    void on_buttonGraficar_clicked();

    void deTextoALista(const QString & textocrudo);

    void graficar(QPen penPol);

    Punto promedio();

    Punto maximo();

    void on_actionTriangulacionminima_triggered();

    void on_buttonAgrandar_clicked();

    void on_buttonAchicar_clicked();

    void on_actionCargar_triggered();

    void on_actionGuardar_triggered();

    void on_actionSalir_triggered();

    void modificarGrosor(int valor);

    void on_actionBorde_triggered();

private:
    Ui::MainWindow *ui;
};
#endif // MAINWINDOW_H
