#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "Punto.h"
#include <QColorDialog>
#include <QDebug>
#include <QFileDialog>
#include <QGraphicsView>
#include <QGraphicsScene>

//Metodo de convertir el string en un punto


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    //Crea una scena para ver el poligono

    //color y grosor de las lineas del grafico
    penPol.setColor(Qt::black);
    penPol.setWidth(5);

    //crea una ventana para imprimir por pantalla los resultados de la matriz
    vTriangulacion = new ventanaTriangulacion(this);
    vTriangulacion->setWindowTitle("Calculo de la triangulacion");

    //Crea una ventana para modificar el grosor del borde
    vGrosor = new VentanaBorde(this);
    vGrosor->setWindowTitle("Editar borde");

    //Corrector de escala

    //Crea una ventana para imprimir por pantalla cuando ingresa un punto no valido
    ventanaError = new Dialogo(this);
    ui->setupUi(this);
    ui->graphicsView->scale(1,-1);
}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_actionArea_triggered()
{

}

void MainWindow::on_actionFondo_triggered()
{
    QString textEdit;
    QColor colorFondo;
    colorFondo = QColorDialog::getColor(Qt::white,this);
    penPol.setColor(colorFondo);
    graficar(penPol);
}

void MainWindow::on_actionTriangulacionminima_triggered()
{

    Poligono p(listaPoligono);
    double ** matrizCosto=0;
    double ** matrizK=0;
    double aux = 0;
    aux= p.triangulacion(matrizCosto,matrizK);
    vTriangulacion->imprimeCosto(aux);
    qDebug()<<"1";
    vTriangulacion->mostrarMatrizCosto(matrizCosto,p.sizePoligono());
    qDebug()<<"2";
    vTriangulacion->mostrarMatrizK(matrizK,p.sizePoligono());
    qDebug()<<"3";
    vTriangulacion->show();
}

void MainWindow::deTextoALista(const QString & textocrudo)
{
    bool okx=false,oky=false;
    int i=0;
    int w=ui->graphicsView->width();
    int h=ui->graphicsView->height();
    while (i<textocrudo.size())
    {
        int cont= 0;
        while ((textocrudo.at(i)!="(") && (i<textocrudo.size()))
            i++;
        i++;

        while ((textocrudo.at(i)!=",") && (i<textocrudo.size()))
        {
            cont++;
            i++;
        }
        QStringRef subStringx(&textocrudo, i-cont, cont);

        double x = subStringx.toDouble(&okx);

        i++;
        cont= 0;

        while ((textocrudo.at(i)!=")") && (i<textocrudo.size()))
        {
            cont++;
            i++;
        }
        QStringRef subStringy(&textocrudo, i-cont, cont);

        double y = subStringy.toDouble(&oky);

        i+=2;

        if((okx)&&(oky))
        {
            Punto auxPoligono(x,y);
            listaPoligono.push_back(auxPoligono);
            Punto auxGrafico(x+(w/2),y+(h/2));
            listaGrafico.push_back(auxGrafico);
        }
    }

    if (listaPoligono.isEmpty())
    {
        ventanaError->show();
        ventanaError->cambiartexto("Ingrese un punto valido (por ejemplo (5,2))");
    }
}

void MainWindow::cargarEnListWidget()
{
    int i=0;
    ui->listWidget->clear();
    while (i<listaPoligono.size())
    {
        ui->listWidget->addItem("(" + QString::number(listaPoligono.at(i).getX()) + ", " + QString::number(listaPoligono.at(i).getY()) + ")");
        qDebug() << "(" << listaPoligono.at(i).getX() << ", " << listaPoligono.at(i).getY() << ")";
        i++;
    }
}
void MainWindow::on_buttonAgregar_clicked()
{
    //ui->textPunto->setValidator()
    QString textocrudo = ui->textPunto->text();
    deTextoALista(textocrudo);
    cargarEnListWidget();
    //(7.5,3.5),(8,4),(8,5),(7,5),(7,4)
    ui->textPunto->clear();
}

void MainWindow::on_buttonEliminar_clicked()
{
    QModelIndex i=ui->listWidget->currentIndex();
    int j=i.row();
    int aux=0;
    listaPoligono.removeAt(j);
    while (aux<listaPoligono.size())
    {
        qDebug() << "(" << listaPoligono.at(aux).getX() << ", " << listaPoligono.at(aux).getY() << ")";
        aux++;
    }
    qDebug() << "";
    delete ui->listWidget->currentItem();
}

Punto MainWindow::promedio()
{
    double x=0, y=0;
    for (int i=0; i< listaGrafico.size(); i++)
    {
        x+=listaGrafico[i].getX();
        y+=listaGrafico[i].getY();
    }
    int size=listaGrafico.size();
    Punto aux(x/size,y/size);
    return aux;
}
Punto MainWindow::maximo()
{
    Punto aux(0,0);
    for(int i=0; i< listaPoligono.size(); i++)
    {
        if (listaPoligono[i].getX()>aux.getX())
            aux.setX(listaPoligono[i].getX());
        if (listaPoligono[i].getY()>aux.getY())
            aux.setY(listaPoligono[i].getY());
    }
    return aux;
}
void MainWindow::graficar(QPen penPol)
{
    double radio= 5;
    int j = listaGrafico.size()-1;
    QGraphicsScene *scene = new QGraphicsScene;

    if (j>1)
    {
        for(int i = 0; i< j; i++)
        {
            //Agrego lineas entre cada par de puntos
            if (i<j)
                scene->addLine(listaGrafico[i].getX(), listaGrafico[i].getY(), listaGrafico[i+1].getX(), listaGrafico[i+1].getY(), penPol);
        }
        scene->addLine(listaGrafico[j].getX(), listaGrafico[j].getY(), listaGrafico[0].getX(), listaGrafico[0].getY(), penPol);

        //Calculo el promedio de los puntos, y creo un punto donde deberia estar el centro
        Punto aux(promedio());
        qDebug() << "(" << aux.getX() << ", " << aux.getY() << ")";
        scene->addEllipse(aux.getX()-radio/2, aux.getY()-radio/2, radio, radio);
        //double w = ui->graphicsView->width();
        //double h = ui->graphicsView->height();
        ui->graphicsView->centerOn(aux.getX(),aux.getY());

        //Muestro la escena en la vista
        ui->graphicsView->setScene(scene);
        ui->graphicsView->show();
    }
    else
    {
        ventanaError->cambiartexto("No hay suficientes puntos para formar un poligono");
        ventanaError->show();
    }
}

void MainWindow::on_buttonGraficar_clicked()
{
    graficar(penPol);
    ui->graphicsView->show();
}

void MainWindow::on_actionCargar_triggered()
{
    QString nombreArchivo= QFileDialog::getOpenFileName(this, tr("Abrir archivo"), "C:://", "Todos los archivos (*.*);;Archivos de texto (*.txt)");
    QFile data;
    data.setFileName(nombreArchivo);
    if (!data.open(QIODevice::ReadOnly))
    {
        ventanaError->cambiartexto("El archivo deseado no se ha podido cargar");
        ventanaError->show();
        return;
    }
    QString textocrudo = data.readAll();
    ui->textPunto->setText(textocrudo);
    on_buttonAgregar_clicked();
    data.close();
}

void MainWindow::on_actionGuardar_triggered()
{
    QString dataAGuardar;
    for (int i=0; i< listaPoligono.size(); i++)
        dataAGuardar = dataAGuardar + " (" + QString::number(listaPoligono.at(i).getX()/100) + ", " + QString::number(listaPoligono.at(i).getY()/100) + ")";

    QString nombreArchivo= QFileDialog::getOpenFileName(this, tr("Guardar archivo"), "C:://");
    /*
    QFile data;
    data.setFileName(nombreArchivo);
    if (!data.exists())
    {
        QTextStream out(&nombreArchivo);
        out << dataAGuardar;
    }
    else
    {
        data.open(QIODevice::WriteOnly);
        data.flush();

        QByteArray aux;
        aux.append(dataAGuardar);
        data.write(aux);
    }
    data.close();
    */
    QFile file;
    file.setFileName(nombreArchivo +".txt");//file_name is the QString, which I get as aparameter
    file.open(QIODevice::ReadWrite | QIODevice::Text);
    QTextStream stream(&file);
    stream<<"Create Document";
    file.close();



    /*
     * // Este codigo anda, pero no me deja crear archivos nuevos
     *
    QString nombreArchivo= QFileDialog::getOpenFileName(this, tr("Guardar archivo"), "C:://");
    QFile data;
    data.setFileName(nombreArchivo);
    data.open(QIODevice::WriteOnly);
    data.flush();

    QString dataAGuardar;
    for (int i=0; i< listaPuntos.size(); i++)
        dataAGuardar = dataAGuardar + " (" + QString::number(listaPuntos.at(i).getX()/100) + ", " + QString::number(listaPuntos.at(i).getY()/100) + ")";
    QByteArray aux;
    aux.append(dataAGuardar);
    data.write(aux);
    data.close();
    */
}

void MainWindow::on_buttonAgrandar_clicked()
{
    double factorDeConversion=1.25;
    int size=listaGrafico.size();
    for(int i=0; i < size; i++)
    {
        Punto aux = listaGrafico.first();
        listaGrafico.pop_front();
        aux*factorDeConversion;
        listaGrafico.push_back(aux);
    }
    on_buttonGraficar_clicked();
}

void MainWindow::on_buttonAchicar_clicked()
{

    double factorDeConversion=0.80;
    int size=listaGrafico.size();
    for(int i=0; i < size; i++)
    {
        Punto aux = listaGrafico.first();
        listaGrafico.pop_front();
        aux*factorDeConversion;
        listaGrafico.push_back(aux);
    }
    on_buttonGraficar_clicked();
}
void MainWindow::on_actionSalir_triggered()
{
    QApplication::quit();
}

void MainWindow::modificarGrosor(int valor)
{
    qDebug() << "entro modificargrosor";
    penPol.setWidth(valor);
    graficar(penPol);
    qDebug()<< "apreto ok";
}

void MainWindow::on_actionBorde_triggered()
{
    vGrosor->show();
    graficar(penPol);
}
