#include "ventanaperimetro.h"
#include "ui_ventanaperimetro.h"

VentanaPerimetro::VentanaPerimetro(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::VentanaPerimetro)
{
    ui->setupUi(this);
}

VentanaPerimetro::~VentanaPerimetro()
{
    delete ui;
}
