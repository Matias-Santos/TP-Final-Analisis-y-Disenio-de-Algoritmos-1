#ifndef VENTANAPERIMETRO_H
#define VENTANAPERIMETRO_H

#include <QDialog>

namespace Ui {
class VentanaPerimetro;
}

class VentanaPerimetro : public QDialog
{
    Q_OBJECT

public:
    explicit VentanaPerimetro(QWidget *parent = nullptr);
    ~VentanaPerimetro();

private:
    Ui::VentanaPerimetro *ui;
};

#endif // VENTANAPERIMETRO_H
