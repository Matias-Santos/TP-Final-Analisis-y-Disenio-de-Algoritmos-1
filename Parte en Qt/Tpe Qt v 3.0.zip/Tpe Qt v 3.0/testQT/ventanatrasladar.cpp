#include "ventanatrasladar.h"
#include "ui_ventanatrasladar.h"

VentanaTrasladar::VentanaTrasladar(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::VentanaTrasladar)
{
    ui->setupUi(this);
    connect(this,SIGNAL(apretoOK(double,double)),parent,SLOT(trasladar(double,double)));
}


VentanaTrasladar::~VentanaTrasladar()
{
    delete ui;
}

void VentanaTrasladar::on_ok_accepted()
{
    emit apretoOK(ui->valorX->value(),ui->valorY->value());
}
