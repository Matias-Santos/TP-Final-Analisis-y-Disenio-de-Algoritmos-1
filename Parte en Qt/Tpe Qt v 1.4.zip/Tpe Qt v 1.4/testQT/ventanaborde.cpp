#include "ventanaborde.h"
#include "ui_ventanaborde.h"
#include <QDebug>

VentanaBorde::VentanaBorde(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::VentanaBorde)
{
    ui->setupUi(this);
    qDebug() << "conecto: " << connect(this,SIGNAL(apretoOK(int)),parent,SLOT(modificarGrosor(int)));
}

VentanaBorde::~VentanaBorde()
{
    delete ui;
}


void VentanaBorde::on_sliderGrosor_valueChanged(int value)
{
    QGraphicsScene * scene= new QGraphicsScene();
    scene->clear();
    QPen aux;
    aux.setColor(Qt::black);
    aux.setWidth(value);
    int ancho = ui->graficoDeMuestra->width();
    int alto = ui->graficoDeMuestra->height();
    scene->addLine(ancho*0.2,alto/2,ancho*0.8,alto/2,aux);
    ui->graficoDeMuestra->setScene(scene);
    ui->spinBox->setValue(value);
}

void VentanaBorde::on_Ok_accepted()
{
    qDebug()<< "emitio: ";
    emit apretoOK(ui->sliderGrosor->value());
    qDebug()<< "salio de emitir";
}

void VentanaBorde::on_spinBox_valueChanged(int value)
{
    QGraphicsScene * scene= new QGraphicsScene();
    scene->clear();
    QPen aux;
    aux.setColor(Qt::black);
    aux.setWidth(value);
    ui->sliderGrosor->setValue(value);
    int ancho = ui->graficoDeMuestra->width();
    int alto = ui->graficoDeMuestra->height();
    scene->addLine(ancho*0.2,alto/2,ancho*0.8,alto/2,aux);
    ui->graficoDeMuestra->setScene(scene);
}
