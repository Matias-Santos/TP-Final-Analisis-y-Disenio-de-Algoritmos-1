#ifndef MAINWINDOW_H
#define MAINWINDOW_H
#include <QMainWindow>
#include <QPen>
#include <QDesktopServices>
#include <QUrl>
#include <QGraphicsScene>
#include "Punto.h"
#include "poligono.h"
#include "VentanaError.h"
#include "ventanatriangulacion.h"
#include "ventanatrasladar.h"

#include "ventanaborde.h"

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);

    ~MainWindow();
private:

    QPen penPuntos;
    QPen penPol;
    QList<Punto> listaPoligono;
    QList<Punto> listaGrafico;
    QList<Punto> listaCuerdas;
    ventanaTriangulacion * vTriangulacion;
    VentanaError * vError;
    VentanaBorde * vGrosor;
    VentanaTrasladar * vTrasladar;
    QGraphicsScene * scene;
    double factorDeCorreccion;
    double radio;
    bool graficado;
    bool esConvexo;


private slots:
    Punto promedio();

    Punto maximo();

    void cargarEnListWidget();

    void on_buttonAgregar_clicked();

    void on_buttonEliminar_clicked();

    void on_buttonGraficar_clicked();

    void deTextoALista(const QString & textocrudo);

    void graficarEjes();

    void graficar();

    void on_buttonAgrandar_clicked();

    void on_buttonAchicar_clicked();

    void on_actionNuevo_triggered();

    void on_actionCargar_triggered();

    void on_actionGuardar_triggered();

    void on_actionSalir_triggered();

    void on_actionColor_triggered();

    void modificarGrosor(int valor);

    void on_actionBorde_triggered();

    void on_actionArea_triggered();

    void on_actionPerimetro_triggered();

    void trazarCuerdas();

    void on_actionTriangulacionminima_triggered();

    void on_actionInstrucciones_triggered();

    void on_actionTransformar_a_Convexo_triggered();

    void on_actionTrasladar_triggered();

    void trasladar(double x, double y);

private:
    Ui::MainWindow *ui;

};
#endif // MAINWINDOW_H
