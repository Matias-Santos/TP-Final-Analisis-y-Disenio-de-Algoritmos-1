#include "ventanatriangulacion.h"
#include "ui_ventanatriangulacion.h"
#include <QtDebug>

ventanaTriangulacion::ventanaTriangulacion(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::ventanaTriangulacion)
{
    ui->setupUi(this);
}

ventanaTriangulacion::~ventanaTriangulacion()
{
    delete ui;
}

void ventanaTriangulacion::imprimeCosto(double aux)
{
   QString aux2("Costo minimo de la triangulacion: " + QString::number(aux));
   ui->costoMinimo->setText(aux2);
}

void ventanaTriangulacion::mostrarMatrizCosto(double ** & matriz,int n)
{
    ui->MatrizCosto->setColumnCount(n);
    ui->MatrizCosto->setRowCount(n-2);
    QStringList titulosCol;
    QStringList titulosFil;
    for(int i=0;i<n;i++)
    {
        QString indiceI= QString::number(i);
        titulosCol.push_back("i= " + indiceI);
        QString indiceS=QString::number(n-i);
        titulosFil.push_back("s= " + indiceS);
        QTableWidgetItem *item = new QTableWidgetItem("0");
        item->setFlags(item->flags() ^ (Qt::ItemIsSelectable|Qt::ItemIsEditable));
        ui->MatrizCosto->setItem(0,i,item);
    }
    ui->MatrizCosto->setHorizontalHeaderLabels(titulosCol);
    ui->MatrizCosto->setVerticalHeaderLabels(titulosFil);
    double aux= matriz[n][0];
    QString valor= QString::number(aux);
    QTableWidgetItem *item = new QTableWidgetItem(valor);
    item->setFlags(item->flags() ^ (Qt::ItemIsSelectable|Qt::ItemIsEditable));
    ui->MatrizCosto->setItem(0,0,item);

    int j=1;
    for (int f = n-1; f > 2; f--)
    {
        for(int c=0; c< n ; c++)
        {
            aux= matriz[f][c];
            QString valor= QString::number(aux);
            QTableWidgetItem *item = new QTableWidgetItem(valor);
            item->setFlags(item->flags() ^ (Qt::ItemIsSelectable|Qt::ItemIsEditable));
            ui->MatrizCosto->setItem(j,c,item);
        }
        j++;
   }
    QHeaderView * headerHorizontal= ui->MatrizCosto->horizontalHeader();
    QHeaderView * headerVertical= ui->MatrizCosto->verticalHeader();
    headerHorizontal->setSectionResizeMode(QHeaderView::Stretch);
    headerVertical->setSectionResizeMode(QHeaderView::Stretch);
}
void ventanaTriangulacion::mostrarMatrizK(double ** & matriz,int n)
{

    ui->MatrizK->setColumnCount(n);
    ui->MatrizK->setRowCount(n-2);
    QStringList titulosCol;
    QStringList titulosFil;
    for(int i=0;i<n;i++)
    {
        QString indiceI= QString::number(i);
        titulosCol.push_back("i= " + indiceI);
        QString indiceS=QString::number(n-i);
        titulosFil.push_back("s= " + indiceS);
        QTableWidgetItem *item = new QTableWidgetItem("0");
        item->setFlags(item->flags() ^ (Qt::ItemIsSelectable|Qt::ItemIsEditable));
        ui->MatrizK->setItem(0,i,item);
    }
    ui->MatrizK->setHorizontalHeaderLabels(titulosCol);
    ui->MatrizK->setVerticalHeaderLabels(titulosFil);
    double aux= matriz[n][0];
    QString valor= QString::number(aux);
    QTableWidgetItem *item = new QTableWidgetItem(valor);
    item->setFlags(item->flags() ^ (Qt::ItemIsSelectable|Qt::ItemIsEditable));
    ui->MatrizK->setItem(0,0,item);
    int j=1;
    for (int f = n-1; f > 2; f--)
    {
        for(int c=0; c < n ; c++)
        {
            aux= matriz[f][c];
            QString valor= QString::number(aux);
            QTableWidgetItem *item = new QTableWidgetItem(valor);
            item->setFlags(item->flags() ^ (Qt::ItemIsSelectable|Qt::ItemIsEditable));
            ui->MatrizK->setItem(j,c,item);
        }
        j++;
    }
    QHeaderView * headerHorizontal= ui->MatrizK->horizontalHeader();
    QHeaderView * headerVertical= ui->MatrizK->verticalHeader();
    headerHorizontal->setSectionResizeMode(QHeaderView::Stretch);
    headerVertical->setSectionResizeMode(QHeaderView::Stretch);
}
