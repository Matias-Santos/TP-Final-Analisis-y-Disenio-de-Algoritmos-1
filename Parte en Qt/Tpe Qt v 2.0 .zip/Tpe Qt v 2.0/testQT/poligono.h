#ifndef POLIGONO_H
#define POLIGONO_H
#include "punto.h"
#include <QList>

class Poligono
{
    private:
        QList<Punto> pol;
        QVector<Punto> vecP;
        void agregarPrivado(Punto aAgregar);
        void crearMatriz(double ** & matriz, int columna, int fila);
        void preCargaMatriz(double ** & matriz, int columna, int fila);

public:
        Poligono(QList<Punto> listpunto);
        ~Poligono();
        void agregar(Punto aAgregar);
        int sizePoligono();
        QVector<Punto> devuelveCopiaEnVector();
        double calcularArea();
        double calcularPerimetro();
        void triangulacion(double ** & matrizCosto,double ** & matrizK,double & valor);
        Punto calcularcentro();
        void trazarLineas(QList<Punto> &lineas,int &s, int &k, int &i, double **matrizK);
        void convexHull(QList<Punto> &convexo);
};

#endif // POLIGONO_H
