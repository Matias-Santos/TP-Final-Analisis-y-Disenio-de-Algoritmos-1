#include "mainwindow.h"
#include "punto.h"
#include "poligono.h"
#include <QApplication>
#include <QDebug>
#include <QList>

using namespace std;

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;
    //w.setWindowIcon(QIcon(":\Tpe Qt v 2.0 emprolijado\testQT\logoMainWindow.png"));
    w.showNormal();
    return a.exec();
}
