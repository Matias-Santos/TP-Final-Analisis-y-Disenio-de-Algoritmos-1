#include "poligono.h"
#include "poligono.h"
#include <iterator>
#include <QDebug>

//---------------------Metodos privados-------------------
void Poligono::agregarPrivado(Punto aAgregar)
{
    pol.push_back(aAgregar);
}

//Metodo para crear la matriz O(n) siendo n la cantidad de filas
void Poligono::crearMatriz(double ** & matriz, int columna, int fila)
{
    matriz = new double*[fila];
    for (int f = 0; f <= fila; f++)
        matriz[f] = new double[columna];
}

//Metodo para preCargar la matriz O(n^m) siendo n la cantidad de filas y m la cantidad de columnas
void Poligono::preCargaMatriz(double ** & matriz, int columna, int fila)
{
    for(int i=0; i<=fila; i++)
        for(int j=0; j<columna; j++)
                matriz[i][j]= 0;
}

void Poligono::mostraraMatriz(double **matriz, int columna, int fila)
{
    for (int f = fila-1; f > 2; f--)
    {
        for (int c = 0; c < columna; c++)
        {
            double aux=0.0;
            aux=matriz[f][c];
            qDebug() << matriz[f][c] ;
        }
        qDebug() << "\n";
    }
    qDebug() <<"";
}

//Metodo para trazar las lineas del poligono

void Poligono::trazarLineas(QList<Punto> & lineas,int & s, int & k, int & i,double ** matrizK)
    {
        //calculo el nuevo k
        k=matrizK[s][i];

        //calculo los vertices a agregar;
        if(((i+1)!=(i+k))&&((i-1)!=(i+k)))
        {
            lineas.push_back(vecP.at(i));
            lineas.push_back(vecP.at(i+k));
        }
        if(((i+s-1)!=(i+k+1))&&((i+s-1)!=(i+k-1)))
        {
            lineas.push_back(vecP.at(i+k));
            lineas.push_back(vecP.at(i+s-1));
        }

        //llamo a las nuevas sol
        if(matrizK[k+1][i]!=0)
        {
            s=k+1;
            trazarLineas(lineas,s,k,i,matrizK);
        }
        if(matrizK[s-k][i+k]!=0)
        {
            s=s-k;
            i=i+k;
            trazarLineas(lineas,s,k,i,matrizK);
        }
    }

//---------------------Metodos publicos--------------------

//Metodo constructor de la clase O(n)
Poligono::Poligono(QList<Punto> listpunto)
{
    QList<Punto>::iterator i;
    for(i=listpunto.begin();i< listpunto.end();i++)
    {
        vecP.push_back(*i);
        pol.push_back(*i);
    }
}

//Metodo destructor de la clase O(n)
Poligono::~Poligono()
{
    pol.clear();
}

//Metodo agregar publico que se encarga de llamar al privado O(1)
void Poligono::agregar(Punto aAgregar)
{
    agregarPrivado(aAgregar);
}

//Metodo que retorna el tamaño del poligono O(1)
int Poligono::sizePoligono()
{
    return pol.size();
}

//Metodo que retorna la copia en un vector
QVector<Punto> Poligono::devuelveCopiaEnVector()
{
    QVector<Punto> vecpol;
    QList<Punto>::Iterator it;
    for(it=pol.begin();it<pol.end();it++)
    {
        vecpol.push_back(*it);
    }
    return vecpol;
}

//Metodo para calcular el area de un poligono O(n)
double Poligono::calcularArea()
{
    double area=0.0;
    QList<Punto>::Iterator itp;
    itp=pol.begin();
    Punto inic= *itp;
    for (int i=0; i<pol.size()-1; i++)
    {
        Punto a=*itp;
        itp++;
        Punto b=*itp;
        area+=a.distancia(b);
    }
    Punto fin = *itp;
    area+=inic.distancia(fin);
    if(area < 0)
        return area*(-0.5);
    else
        return area*(0.5);
}

//Metodo para calcular el perimetro de un poligono O(n)
double Poligono::calcularPerimetro()
{
    double perimetro=0.0;
    QList<Punto>::Iterator itp=pol.begin();
    Punto inic= *itp;
    for (int i=0; i<pol.size()-1; i++)
    {
        Punto a=*itp;
        itp++;
        Punto b=*itp;
        perimetro+=a.distancia(b);
    }
    Punto fin = *itp;
    perimetro+=inic.distancia(fin);
    return perimetro;
}

//Metodo para calcular la triangulacion O(n^3)
double Poligono::triangulacion(double ** & matrizCosto,double ** & matrizK)
{
    int tam = pol.size();
    if(tam<4)
        return 0;
    //Pasaje de lista a vector

    //Inicializacion de la matriz
    matrizCosto=0;
    matrizK=0;
    crearMatriz(matrizCosto,tam,tam);
    preCargaMatriz(matrizCosto,tam,tam);
    crearMatriz(matrizK,tam,tam);
    preCargaMatriz(matrizK,tam,tam);

    qDebug()<< "inicio del algoritmo";
    //Algoritmo
    for(int s=4; s<=tam; s++)
        for(int i=0; i<tam; i++)
            for(int k=1; k<=s-2; k++)
            {
                Punto a,b,c;
                a.copiarPunto(vecP.at(i));
                double valorMat1,valorMat2,aux=0;
                if(i+k > tam-1)
                {
                    b.copiarPunto(vecP.at(i+k-tam));
                    valorMat1=(matrizCosto[k+1][i]);
                    valorMat2=(matrizCosto[s-k][i+k-tam]);
                }
                else
                {
                    b.copiarPunto(vecP.at(i+k));
                    valorMat1=(matrizCosto[k+1][i]);
                    valorMat2=(matrizCosto[s-k][i+k]);
                }
                if(i+s-1 > tam-1)
                    c.copiarPunto(vecP.at(i+s-1-tam));
                else
                    c.copiarPunto(vecP.at(i+s-1));
                if ((i+1==i+k)||(i-1==i+k))
                    aux = valorMat1 + valorMat2 + b.distancia(c);
                else if(((i+k+1)==(i+s-1))||((i+k-1)==(i+s-1)))
                    aux = valorMat1 + valorMat2 + a.distancia(b);
                else
                    aux= valorMat1 + valorMat2 + a.distancia(b) + b.distancia(c);
                if((matrizCosto[s][i]>= aux)||(matrizCosto[s][i]==0))
                {
                    matrizCosto[s][i]=aux;
                    matrizK[s][i]=k;
                }
            }
    qDebug()<< "fin del algoritmo";
    return matrizCosto[tam][0];
}

Punto Poligono::calcularcentro()
{
    double xaux=0,yaux=0;
    QList<Punto>:: iterator it;
    Punto aux(0,0);
    for(it=pol.begin();it!=pol.end();it++)
    {
        aux=*it;
        xaux+=aux.getX();
        yaux+=aux.getY();
    }
    aux.setX(xaux/pol.size());
    aux.setY(yaux/pol.size());
    return aux;
}

//Metodo que encuentra el menor punto en y para jarvin O(n)

void Poligono::buscarMenorPuntoEnY(Punto & menor)
{
    QList<Punto>:: iterator it=pol.begin();
    while (it!=pol.end())
    {
        Punto aux=*it;
        if (aux.getY() < menor.getY())
            menor=*it;
        it++;
    }
}

//Metodo que encuentra el mayor punto en y para jarvin O(n)

void Poligono::BuscarMayorPuntoEnY(Punto & mayor)
{
    QList<Punto>:: iterator it=pol.begin();
    while (it!=pol.end())
    {
        Punto aux=*it;
        if (aux.getY() > mayor.getY())
            mayor=*it;
        it++;
    }
}

//Metodo que encuentra el mejor punto en la cadena derecha O(1)

void Poligono::mejorPuntoCadenaDerecha(Punto p0,Punto p1,Punto p2,Punto & posible_punto)
{
    if (p1 != p2)
    {
        Punto aux1=p1;
        Punto aux2=p2;
        aux1.setX(aux1.getX()-p0.getX());
        aux2.setX(aux2.getX()-p0.getX());
        aux1.setY(aux1.getY()-p0.getY());
        aux2.setY(aux2.getY()-p0.getY());
        if (aux1.productoCruzado(aux2) > 0)
            posible_punto = p1;
        else
        {
            if (aux1.productoCruzado(aux2) < 0)
                posible_punto = p2;
            else
            {
                if (aux1.getY() > aux2.getY())
                    posible_punto=p1;
                else
                    posible_punto=p2;
            }
        }
    }
    else
        posible_punto=p1;
}

//Metodo que encuentra el mejor punto en la cadena izquierda O(1)

void Poligono::mejorPuntoCadenaIzquierda(Punto p0,Punto p1,Punto p2,Punto & posible_punto)
{
    if (p1!=p2)
    {
        Punto aux1=p1;
        Punto aux2=p2;
        aux1.setX(aux1.getX()-p0.getX());
        aux2.setX(aux2.getX()-p0.getX());
        aux1.setY(aux1.getY()-p0.getY());
        aux2.setY(aux2.getY()-p0.getY());
        if (aux1.productoCruzado(aux2) > 0)
            posible_punto = p1;
        else
        {
            if (aux1.productoCruzado(aux2) < 0)
                posible_punto = p2;
            else
                if (aux1.getY() < aux2.getY())
                    posible_punto=p1;
                else
                    posible_punto=p2;
        }
    }
    else
        posible_punto=p1;
}

//Metodo jarvis devuelve un poligono convexo O(nh)

void Poligono::jarvis (QList<Punto> & convexhull)
{
    Punto menor(9999.9,9999.9);
    Punto mayor(-9999.9,-9999.9);
    buscarMenorPuntoEnY(menor);
    BuscarMayorPuntoEnY(mayor);
    qDebug()<<"crash aa1";
    QList<Punto>:: iterator it=pol.begin();
    Punto p1=*it;
    it++;
    Punto p2=*it;
    if(p1==menor)
    {
        it++;
        p1=*it;
    }
    else
        if(p2==menor)
        {
            it++;
            p2=*it;
        }
    Punto actual=menor;
    Punto posible_punto(0,0);
    //calculo cadena derecha
    qDebug()<<"crashaa 2";
    int i=0;
    qDebug()<<"("<<mayor.getX()<<","<<mayor.getY()<<")";
    while (actual!=mayor)
    {
        qDebug()<<"("<<actual.getX()<<","<<actual.getY()<<")";
        qDebug()<<"iteracion: "<< i;
        it=pol.begin();
        while (it != pol.end())
        {

            mejorPuntoCadenaDerecha(actual, p1,p2, posible_punto);
            p1=posible_punto;
            p2=*it;
            it++;


        }
        actual=p1;
        convexhull.push_front(actual);
        i++;

    }
    qDebug()<<"crashaa 3";
    //calculo cadena izquierda
    while (actual!=menor)
    {
        it=pol.begin();
        while (it!=pol.end())
        {
            mejorPuntoCadenaIzquierda(actual, p1, p2, posible_punto);
            p1=posible_punto;
            p2=*it;
            it++;
        }
        actual=p1;
        convexhull.push_front(actual);
    }
}
