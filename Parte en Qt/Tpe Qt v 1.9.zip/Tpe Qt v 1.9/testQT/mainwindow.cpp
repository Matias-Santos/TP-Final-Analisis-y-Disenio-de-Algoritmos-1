#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "Punto.h"
#include <QColorDialog>
#include <QDebug>
#include <QFileDialog>
#include <QGraphicsView>
#include <QGraphicsScene>

//Metodo de convertir el string en un punto


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    //Crea una scena para ver el poligono
    scene = new QGraphicsScene;

    //color y grosor de las lineas del grafico
    penPol.setColor(Qt::black);
    penPol.setWidth(5);
    penEjes.setColor(Qt::black);
    penEjes.setWidth(2);

    //color, grosor y radio de los puntos del grafico
    penPuntos.setColor(Qt::blue);
    penPuntos.setWidth(5);
    radio=5;

    //crea una ventana para imprimir por pantalla los resultados de la matriz
    vTriangulacion = new ventanaTriangulacion(this);
    vTriangulacion->setWindowTitle("Calculo de la triangulacion");

    //Crea una ventana para modificar el grosor del borde
    vGrosor = new VentanaBorde(this);
    vGrosor->setWindowTitle("Editar borde");

    //Corrector de escala
    factorDeCorreccion=100;

    graficado = false;
    esConvexo=true;

    //Crea una ventana para imprimir por pantalla un error
    vError = new VentanaError(this);
    vError->setWindowTitle("Advertencia");

    //creo una ventana para ver cuanto quiere mover el usuario al trasladar poligono
    vTrasladar= new VentanaTrasladar(this);
    vTrasladar->setWindowTitle("Trasladar");

    ui->setupUi(this);
    ui->graphicsView->scale(1,-1);
    graficarEjes();
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::deTextoALista(const QString & textocrudo)
{
    bool okx=false,oky=false;
    int i=0;
    int w=ui->graphicsView->width();
    int h=ui->graphicsView->height();
    while (i<textocrudo.size())
    {
        int cont= 0;
        while ((i<textocrudo.size()) && (textocrudo.at(i)!="("))
            i++;
        i++;

        while ((i<textocrudo.size()) && (textocrudo.at(i)!=","))
        {
            cont++;
            i++;
        }
        QStringRef subStringx(&textocrudo, i-cont, cont);

        double x = subStringx.toDouble(&okx);

        i++;
        cont= 0;

        while ((i<textocrudo.size()) && (textocrudo.at(i)!=")"))
        {
            cont++;
            i++;
        }
        QStringRef subStringy(&textocrudo, i-cont, cont);

        double y = subStringy.toDouble(&oky);

        i+=2;

        if((okx)&&(oky))
        {
            Punto auxPoligono(x,y);
            listaPoligono.push_back(auxPoligono);
            Punto auxGrafico((x+(w/2))*factorDeCorreccion,(y+(h/2))*factorDeCorreccion);
            listaGrafico.push_back(auxGrafico);
        }
    }

    if (listaPoligono.isEmpty())
    {
        vError->show();
        vError->cambiartexto("Ingrese un punto valido (por ejemplo (5,2))");
    }
}

void MainWindow::cargarEnListWidget()
{
    int i=0;
    ui->listWidget->clear();
    while (i<listaPoligono.size())
    {
        ui->listWidget->addItem("(" + QString::number(listaPoligono.at(i).getX()) + ", " + QString::number(listaPoligono.at(i).getY()) + ")");
        qDebug() << "(" << listaPoligono.at(i).getX() << ", " << listaPoligono.at(i).getY() << ")";
        i++;
    }
}
void MainWindow::on_buttonAgregar_clicked()
{
    QString textocrudo = ui->textPunto->text();
    deTextoALista(textocrudo);
    cargarEnListWidget();
    ui->textPunto->clear();
}

void MainWindow::on_buttonEliminar_clicked()
{
    QModelIndex i=ui->listWidget->currentIndex();
    int j=i.row();
    int aux=0;
    listaPoligono.removeAt(j);
    listaGrafico.removeAt(j);
    while (aux<listaPoligono.size())
    {
        qDebug() << "(" << listaPoligono.at(aux).getX() << ", " << listaPoligono.at(aux).getY() << ")";
        aux++;
    }
    qDebug() << "";
    delete ui->listWidget->currentItem();
}

Punto MainWindow::promedio()
{
    double x=0, y=0;
    for (int i=0; i< listaGrafico.size(); i++)
    {
        x+=listaGrafico[i].getX();
        y+=listaGrafico[i].getY();
    }
    int size=listaGrafico.size();
    Punto aux(x/size,y/size);
    return aux;
}
Punto MainWindow::maximo()
{
    Punto aux(0,0);
    for(int i=0; i< listaPoligono.size(); i++)
    {
        if (listaPoligono[i].getX()>aux.getX())
            aux.setX(listaPoligono[i].getX());
        if (listaPoligono[i].getY()>aux.getY())
            aux.setY(listaPoligono[i].getY());
    }
    return aux;
}

void MainWindow::graficarEjes()
{
    scene->clear();
    double tam=5*penEjes.width();
    double w=ui->graphicsView->width();
    double h=ui->graphicsView->height();
    int cont=0;

    //Intervalos:
    //Desde x/2, hasta x
    for (double i=w/2*factorDeCorreccion; i< w*factorDeCorreccion; i=i+factorDeCorreccion)
        {
            if (cont==10)
            {
                scene->addLine(i,(h/2)*factorDeCorreccion-tam*2,i, (h/2)*factorDeCorreccion+tam*2, penEjes);
                cont=0;
            }
            else
                scene->addLine(i,(h/2)*factorDeCorreccion-tam/2,i, (h/2)*factorDeCorreccion+tam/2, penEjes);
            cont++;
        }

    //Desde x/2, hasta 0
    cont=0;
    for (double i=w/2*factorDeCorreccion; i>0; i=i-factorDeCorreccion)
    {
        if (cont==10)
        {
            scene->addLine(i,(h/2)*factorDeCorreccion-tam*2,i, (h/2)*factorDeCorreccion+tam*2, penEjes);
            cont=0;
        }
        else
            scene->addLine(i,(h/2)*factorDeCorreccion-tam/2,i, (h/2)*factorDeCorreccion+tam/2, penEjes);
        cont++;
    }

    //Desde y/2, hasta y
    cont=0;
    for (double i=h/2*factorDeCorreccion; i< h*factorDeCorreccion; i=i+factorDeCorreccion)
    {
        if (cont==10)
        {
            scene->addLine((w/2)*factorDeCorreccion-tam*2, i,(w/2)*factorDeCorreccion+tam*2, i, penEjes);
            cont=0;
        }
        else
            scene->addLine((w/2)*factorDeCorreccion-tam/2, i,(w/2)*factorDeCorreccion+tam/2, i, penEjes);
        cont++;
    }

    //Desde y/2, hasta 0
    cont=0;
    for (double i=h/2*factorDeCorreccion; i>0; i=i-factorDeCorreccion)
    {
        if (cont==10)
        {
            scene->addLine((w/2)*factorDeCorreccion-tam*2, i,(w/2)*factorDeCorreccion+tam*2, i, penEjes);
            cont=0;
        }
        else
            scene->addLine((w/2)*factorDeCorreccion-tam/2, i,(w/2)*factorDeCorreccion+tam/2, i, penEjes);
        cont++;
    }

    //Lineas principales
    scene->addLine(0, (h/2)*factorDeCorreccion, w*factorDeCorreccion, (h/2)*factorDeCorreccion, penEjes);
    scene->addLine((w/2)*factorDeCorreccion, 0, (w/2)*factorDeCorreccion, h*factorDeCorreccion, penEjes);
    scene->setSceneRect(0, 0, w*factorDeCorreccion, h*factorDeCorreccion);
    ui->graphicsView->setScene(scene);
    ui->graphicsView->centerOn(scene->width()/2,scene->height()/2);
    ui->graphicsView->show();
}

void MainWindow::graficar()
{
    if (graficado)
    {
        QList<Punto> :: iterator it=listaPoligono.begin();
        listaGrafico.clear();
        double w=ui->graphicsView->width();
        double h=ui->graphicsView->height();
        while (it!=listaPoligono.end())
        {
            Punto aux=*it;
            aux.setX((aux.getX()+w/2)*factorDeCorreccion);
            aux.setY((aux.getY()+h/2)*factorDeCorreccion);
            listaGrafico.push_back(aux);
            it++;
        }
        int j = listaGrafico.size()-1;
        graficarEjes();
        if (j>1)
        {
            //Agrego lineas entre cada par de puntos
            for(int i = 0; i< j; i++)
            {
                if (i<j)
                    scene->addLine(listaGrafico[i].getX(), listaGrafico[i].getY(), listaGrafico[i+1].getX(), listaGrafico[i+1].getY(), penPol);
            }
            scene->addLine(listaGrafico[j].getX(), listaGrafico[j].getY(), listaGrafico[0].getX(), listaGrafico[0].getY(), penPol);

            //Agrego elipses en cada punto del poligono
            for(int i = 0; i< listaGrafico.size(); i++)
                scene->addEllipse(listaGrafico[i].getX()-radio/2, listaGrafico[i].getY()-radio/2, radio, radio, penPuntos);

            //Calculo el promedio de los puntos, y creo un punto donde deberia estar el centro
            Punto aux(promedio());
            qDebug() << "Promedio grafico: " << "(" << aux.getX() << ", " << aux.getY() << ")";
            scene->addEllipse(aux.getX()-radio/2, aux.getY()-radio/2, radio, radio);
            ui->graphicsView->centerOn(aux.getX(),aux.getY());

            //Muestro la escena en la vista
            scene->update();
            ui->graphicsView->setScene(scene);
            ui->graphicsView->show();
        }
        else
        {
            vError->cambiartexto("No hay suficientes puntos para formar un poligono");
            vError->show();
        }
    }
}

void MainWindow::on_buttonGraficar_clicked()
{
    if (listaPoligono.size()>2)
    {
        graficado=true;
        Poligono p(listaPoligono);
        qDebug()<<"crash 1";
        QList<Punto> convexo;
        p.convexHull(convexo);
        qDebug()<<"crash 2";
        if(listaPoligono.size()==convexo.size())
        {
            esConvexo=true;
            graficar();
        }
        else
            {
                esConvexo=false;
                graficar();
                vError->cambiartexto("El poligono ingresado no es convexo");
                vError->show();
            }
    }
    else
        graficarEjes();
    qDebug()<<"crash 3";
}

void MainWindow::on_actionNuevo_triggered()
{
    listaGrafico.clear();
    listaPoligono.clear();
    ui->listWidget->clear();
    ui->textPunto->clear();
    scene->clear();
    ui->graphicsView->setScene(scene);
    graficarEjes();
}

void MainWindow::on_actionCargar_triggered()
{
    QString nombreArchivo = QFileDialog::getOpenFileName(this, tr("Abrir archivo"), "C:://", "Todos los archivos (*.*);;Archivos de texto (*.txt)");
    QFile data(nombreArchivo);
    if (!data.open(QIODevice::ReadOnly))
    {
        vError->cambiartexto("El archivo deseado no se ha podido cargar");
        vError->show();
        return;
    }
    data.open(QIODevice::ReadOnly);
    QString textocrudo = data.readAll();
    ui->textPunto->setText(textocrudo);
    on_buttonAgregar_clicked();
    data.close();
}

void MainWindow::on_actionGuardar_triggered()
{
    QString dataAGuardar;
    for (int i=0; i< listaPoligono.size(); i++)
        dataAGuardar = dataAGuardar + " (" + QString::number(listaPoligono.at(i).getX()/100) + ", " + QString::number(listaPoligono.at(i).getY()/100) + ")";

    QString nombreArchivo= QFileDialog::getOpenFileName(this, tr("Guardar archivo"), "C:://");
    /*
    QFile data;
    data.setFileName(nombreArchivo);
    if (!data.exists())
    {
        QTextStream out(&nombreArchivo);
        out << dataAGuardar;
    }
    else
    {
        data.open(QIODevice::WriteOnly);
        data.flush();

        QByteArray aux;
        aux.append(dataAGuardar);
        data.write(aux);
    }
    data.close();
    */
    QFile file;
    file.setFileName(nombreArchivo +".txt");//file_name is the QString, which I get as aparameter
    file.open(QIODevice::ReadWrite | QIODevice::Text);
    QTextStream stream(&file);
    stream<<"Create Document";
    file.close();



    /*
     * // Este codigo anda, pero no me deja crear archivos nuevos
     *
    QString nombreArchivo= QFileDialog::getOpenFileName(this, tr("Guardar archivo"), "C:://");
    QFile data;
    data.setFileName(nombreArchivo);
    data.open(QIODevice::WriteOnly);
    data.flush();

    QString dataAGuardar;
    for (int i=0; i< listaPuntos.size(); i++)
        dataAGuardar = dataAGuardar + " (" + QString::number(listaPuntos.at(i).getX()/100) + ", " + QString::number(listaPuntos.at(i).getY()/100) + ")";
    QByteArray aux;
    aux.append(dataAGuardar);
    data.write(aux);
    data.close();
    */
}

void MainWindow::on_actionSalir_triggered()
{
    QApplication::quit();
}

void MainWindow::on_buttonAgrandar_clicked()
{
    double factor=1.25;
    factorDeCorreccion*=factor;
    QList<Punto> :: iterator it=listaPoligono.begin();
    listaGrafico.clear();
    double w=ui->graphicsView->width();
    double h=ui->graphicsView->height();
    while (it!=listaPoligono.end())
    {
        Punto aux=*it;
        aux.setX((aux.getX()+w/2)*factorDeCorreccion);
        aux.setY((aux.getY()+h/2)*factorDeCorreccion);
        listaGrafico.push_back(aux);
        it++;
    }
    if (graficado)
        graficar();
    else
        graficarEjes();
    trazarCuerdas();
}

void MainWindow::on_buttonAchicar_clicked()
{
    if (factorDeCorreccion > 1)
    {
        double factor=0.80;
        factorDeCorreccion*=factor;
        QList<Punto> :: iterator it=listaPoligono.begin();
        listaGrafico.clear();
        double w=ui->graphicsView->width();
        double h=ui->graphicsView->height();
        while (it!=listaPoligono.end())
        {
            Punto aux=*it;
            aux.setX((aux.getX()+w/2)*factorDeCorreccion);
            aux.setY((aux.getY()+h/2)*factorDeCorreccion);
            listaGrafico.push_back(aux);
            it++;
        }
        if (graficado)
            graficar();
        else
            graficarEjes();
        trazarCuerdas();
    }
}
/*
void MainWindow::on_buttonAchicar_clicked()
{
    ui->graphicsView->scale(0.8,0.8);
    //penEjes.setWidth(penEjes.width()*1.25*2);
    if (graficado)
        graficar();
    else
        graficarEjes();
}
void MainWindow::on_buttonAgrandar_clicked()
{
    ui->graphicsView->scale(1.25,1.25);
    //penEjes.setWidth(penEjes.width()*0.8*2);
    if (graficado)
        graficar();
    else
        graficarEjes();
}
*/


void MainWindow::on_actionColor_triggered()
{
    QString textEdit;
    QColor colorFondo;
    colorFondo = QColorDialog::getColor(Qt::white,this);
    penPol.setColor(colorFondo);
    graficar();
}

void MainWindow::modificarGrosor(int valor)
{
    qDebug() << "entro modificargrosor";
    penPol.setWidth(valor);
    graficar();
    trazarCuerdas();
    qDebug()<< "apreto ok";
}

void MainWindow::on_actionBorde_triggered()
{
    vGrosor->show();
    graficar();
    trazarCuerdas();
}

void MainWindow::on_actionArea_triggered()
{
    Poligono * pol = new Poligono(listaPoligono);
    double valor = pol->calcularArea();
    VentanaError * ventanaPerimetro = new VentanaError();
    ventanaPerimetro->setWindowTitle("Area");
    QString aux = ( "El area del poligono dado es: " + QString::number(valor) +
                    "\n\nEl mismo se calcula de la siguiente forma: \n");

    ventanaPerimetro->cambiartexto(aux);
    ventanaPerimetro->show();
}

void MainWindow::on_actionPerimetro_triggered()
{
    Poligono * aux = new Poligono(listaPoligono);
    double valor = aux->calcularPerimetro();
    VentanaError * ventanaArea = new VentanaError();
    ventanaArea->setWindowTitle("Perimetro");
    ventanaArea->cambiartexto("El perimetro del poligono dado es: " + QString::number(valor));
    ventanaArea->show();
}

void MainWindow::trazarCuerdas()
{
    if (!listaCuerdas.isEmpty())
    {
        double w = ui->graphicsView->width();
        double h = ui->graphicsView->height();
        QPen penCuerdas;
        penCuerdas.setWidth(penPol.width());
        penCuerdas.setColor(Qt::red);
        QList<Punto> :: iterator it=listaCuerdas.begin();
        while(it!=listaCuerdas.end())
        {
            Punto p1(*it);
            it++;
            if(it!=listaCuerdas.end())
            {
                Punto p2(*it);
                scene->addLine((p1.getX()+w/2)*factorDeCorreccion,(p1.getY()+h/2)*factorDeCorreccion,(p2.getX()+w/2)*factorDeCorreccion,(p2.getY()+h/2)*factorDeCorreccion,penCuerdas);
                qDebug()<< "cuerda: " << "( " << p1.getX() << " , "<< p1.getY() << ")"<< " a " << " ( " <<p2.getX() << " , " << p2.getY() << ")";
            }
            it++;
        }
        ui->graphicsView->setScene(scene);
        ui->graphicsView->show();
    }
}

void MainWindow::on_actionTriangulacionminima_triggered()
{
    qDebug()<<"crash1 mwt";
    if((esConvexo)&&(listaPoligono.size()>2))
    {

        qDebug()<<"crash1 mwt";
        for(int i=0;i<listaPoligono.size();i++)
            qDebug()<<listaPoligono.at(i).getX()<< ", "<< listaPoligono.at(i).getY();
        Poligono p(listaPoligono);
        double ** matrizCosto=0;
        double ** matrizK=0;
        double aux = 0;
        int s=p.sizePoligono(),k=0, i=0;
        qDebug()<<"crash1.5 mwt";
        p.triangulacion(matrizCosto,matrizK,aux);
        qDebug()<<"crash1.5 mwt";
        listaCuerdas.clear();

        qDebug()<<"crash1 mwt";
        p.trazarLineas(listaCuerdas,s,k,i,matrizK);

        qDebug()<<"crash1 mwt";
        vTriangulacion->imprimeCosto(aux);

        qDebug()<<"crash1 mwt";
        vTriangulacion->mostrarMatrizCosto(matrizCosto,p.sizePoligono());

        qDebug()<<"crash1 mwt";
        vTriangulacion->mostrarMatrizK(matrizK,p.sizePoligono());

        qDebug()<<"crash1 mwt";
        trazarCuerdas();

        qDebug()<<"crash1 mwt";
        vTriangulacion->showMaximized();

        qDebug()<<"crash1 mwt";
    }
    else
        if(listaPoligono.size()<2)
        {
                vError->cambiartexto("No ingreso suficientes puntos");
                vError->show();
        }
        else
            if(!esConvexo)
            {
                vError->cambiartexto("El poligono no es convexo por lo tanto no podemos utilizar esta funcion");
                vError->show();
            }
}

void MainWindow::on_actionInstrucciones_triggered()
{
    QString link="https://docs.google.com/document/d/1gD_PvUggSV749vKUXyuX9Vk57SQVOtD_q_VqtjnEDyM/edit";
    QDesktopServices::openUrl(QUrl(link));
}

void MainWindow::on_actionTransformar_a_Convexo_triggered()
{
    if((!esConvexo)&&(listaPoligono.size()>2))
    {
        Poligono p(listaPoligono);
        QList<Punto> convexo;
        p.convexHull(convexo);
        listaPoligono.clear();
        listaPoligono=convexo;
        esConvexo=true;
        cargarEnListWidget();
        graficar();
    }
    else
        if(listaPoligono.size()<=2)
        {
            vError->cambiartexto("No tiene suficientes puntos para formar un poligono");
            vError->show();
        }
        else
        {
            vError->cambiartexto("El poligono ya es convexo");
            vError->show();
        }
}

void MainWindow::trasladar(double x,double y)
{
    int i=0;
    while(i<listaPoligono.size())
    {
        Punto aux=listaPoligono.front();
        listaPoligono.pop_front();
        aux.setX(aux.getX()+x);
        aux.setY(aux.getY()+y);
        listaPoligono.push_back(aux);
        i++;
    }
    cargarEnListWidget();
    graficar();
}

void MainWindow::on_actionTrasladar_triggered()
{
    if(!listaPoligono.isEmpty())
    {
        vTrasladar->show();
    }
    else
    {
        vError->cambiartexto("No existe poligono");
        vError->show();
    }
}

void MainWindow::mousePressEvent(QMouseEvent *event)
{
    if (ui->graphicsView->geometry().contains(event->pos()))
    {
        QPointF aux(ui->graphicsView->mapToScene(event->pos()));
        QPointF auxText(aux);
        /*
        qDebug()<< ui->graphicsView->x();
        qDebug()<< ui->graphicsView->width();
        qDebug()<< ui->graphicsView->maximumSize();
        */
        aux.setX(aux.x()-ui->graphicsView->x());
        aux.setY(aux.y()+4*ui->graphicsView->y());
        qDebug() << " aux: (" << aux.x() << ", " << aux.y() << ")";
        scene->addEllipse(aux.x()-radio/2, aux.y()-radio/2, radio, radio, penPuntos);
        QString texto=ui->textPunto->text();

        double w = scene->width();
        double h = scene->height();
        auxText.setX((aux.x()-w/2)/factorDeCorreccion);
        auxText.setY((aux.y()-h/2)/factorDeCorreccion);

        /*
        double w=scene->width();
        double h=scene->height();
        double gvx= ui->graphicsView->x();
        double gvy= ui->graphicsView->y();
        double x=(auxText.x()-gvx)*2/(w*factorDeCorreccion);
        double y=(auxText.y()-gvy*4)*2/(h*factorDeCorreccion);
        */




        double x=auxText.x();
        double y=auxText.y();
        ui->textPunto->setText(texto + " (" + QString::number(x) + ", " + QString::number(y) + ")");
    }
}

/*

        QPointF aux(ui->graphicsView->mapToScene(event->pos()));
        //ui->graphicsView->mapToScene(event->pos());
        QPointF auxText(aux);
        aux.setX(aux.x()-ui->graphicsView->x());
        aux.setY(aux.y()+4*ui->graphicsView->y());
        qDebug() << " aux: (" << aux.x() << ", " << aux.y() << ")";
        scene->addEllipse(aux.x()-radio/2, aux.y()-radio/2, radio, radio, penPuntos);
        QString texto=ui->textPunto->text();

        double w=ui->graphicsView->width();
        double h=ui->graphicsView->height();
        double x=(aux.x()-(w*2))/factorDeCorreccion;
        double y=(aux.y()-(h*2))/factorDeCorreccion;
        //x=x-ui->graphicsView->x();
        //y=y-ui->graphicsView->y();
        ui->textPunto->setText(texto + " (" + QString::number(x) + ", " + QString::number(y) + ")");
*/

void MainWindow::on_action_Color_vertices_triggered()
{
    {
        QString textEdit;
        QColor colorFondo;
        colorFondo = QColorDialog::getColor(Qt::white,this);
        penPuntos.setColor(colorFondo);
        graficar();
    }
}
