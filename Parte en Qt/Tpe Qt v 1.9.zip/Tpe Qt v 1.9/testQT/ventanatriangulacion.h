#ifndef VENTANATRIANGULACION_H
#define VENTANATRIANGULACION_H

#include <QDialog>

namespace Ui {
class ventanaTriangulacion;
}

class ventanaTriangulacion : public QDialog
{
    Q_OBJECT

public:
    explicit ventanaTriangulacion(QWidget *parent = nullptr);
    ~ventanaTriangulacion();
    void imprimeCosto(double aux);
    void mostrarMatrizCosto(double ** & matriz,int n);
    void mostrarMatrizK(double ** & matriz,int n);
    void inicializaMatrizCosto(int n);
    void inicializaMatrizK(int n);
private:
    Ui::ventanaTriangulacion *ui;
};

#endif // VENTANATRIANGULACION_H
