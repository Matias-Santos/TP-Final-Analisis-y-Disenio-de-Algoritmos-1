#ifndef VentanaError_H
#define VentanaError_H

#include <QDialog>

namespace Ui {
class VentanaError;
}

class VentanaError : public QDialog
{
    Q_OBJECT

public:
    explicit VentanaError(QWidget *parent = nullptr);
    ~VentanaError();
    void cambiartexto(QString a);

private slots:
    void on_aceptarbutton_clicked();

private:
    Ui::VentanaError *ui;
};

#endif // VentanaError_H
