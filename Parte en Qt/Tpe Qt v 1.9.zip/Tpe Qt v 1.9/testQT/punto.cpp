#include "punto.h"
#include <QtMath>
//Metodo constructor de la clase O(1)
Punto::Punto(double x,double y)
{
    this->x=x;
    this->y=y;
}

//Metodo constructor de la clase pero se le pasa un punto por parametro O(1)
Punto::Punto(const Punto & aux)
{
    this->x=aux.getX();
    this->y=aux.getY();
}

//Metodo para setear la coordenada x de un punto O(1)
void Punto::setX(double x)
{
    this->x=x;
}

//Metodo para setear la coordenada y de un punto O(1)
void Punto::setY(double y)
{
    this->y=y;
}

//Metodo que retorna el valor de x O(1)
double Punto::getX() const
{
    return this->x;
}

//Metodo que retorna el valor de y O(1)
 double Punto::getY() const
 {
    return this->y;
 }

//Metodo para copiar un punto a otro O(1)
 void Punto::copiarPunto(Punto aux)
 {
    this->setX(aux.getX());
    this->setY(aux.getY());
 }

//Metodo que calcula la distancia entre dos puntos O(1)
double Punto::distancia(Punto aux)
{
    return qSqrt(qPow(this->getX()- aux.getX(),2) + qPow(this->getY()- aux.getY(),2) );
}

//Metodo para multiplicar por un escalar O(1)
void Punto::operator*(const double & i)
{
    setX(getX()*i);
    setY(getY()*i);
}
//Metodo para igualar los valores de este punto, con el dado O(1)
void Punto::operator=(const Punto & aux)
{
    setX(aux.getX());
    setY(aux.getY());
}
//Metodo para comprobar si dos puntos son iguales O(1)
bool Punto::operator==(Punto aux)
{
    return ((this->getX()==aux.getX())&&(this->getY()==aux.getY()));
}

//Metodo para comprobar si dos puntos son distinto O(1)
bool Punto::operator!=(Punto aux)
{
    return ((this->getX()!=aux.getX())||(this->getY()!=aux.getY()));
}

//Metodo que calcular el producto cruzado O(1)
double Punto::productoCruzado(Punto aux)
{
    return ((this->getX()*aux.getY())-(aux.getX()*this->getY()));
}

//metodo que devuelve para que sentido horario esta un punto con respecto a otros O(1)
int Punto::orientacion(Punto p, Punto r)
{
    int val = (this->getY() - p.getY()) * (r.getX() - this->getX()) -
              (this->getX() - p.getX()) * (r.getY() - this->getY());

    if (val == 0) return 0;  // colineales
    return (val > 0)? 1: 2; // 1 gira en sentido horario, 2 gira en sentido antihorario
}
