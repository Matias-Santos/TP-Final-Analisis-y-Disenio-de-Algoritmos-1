#ifndef POLIGONO_H
#define POLIGONO_H
#include "punto.h"
#include <QList>

class Poligono
{
    private:
        QList<Punto> listaPol;
        void agregarPrivado(Punto aAgregar);
        void crearMatriz(double ** & matriz, int columna, int fila);
        void preCargaMatriz(double ** & matriz, int columna, int fila);

        void buscarMayorYMenorY(Punto& mayorY,Punto& menorY);
        void inicializarPuntos(Punto& p1,Punto& p2, const Punto& puntoActual);
        void calcularMejorPuntoMenor(const Punto& puntoActual, const Punto& p1, const Punto& p2, Punto& mejorPunto);
        void calcularMejorPuntoMayor(const Punto& puntoActual, const Punto& p1, const Punto& p2, Punto& mejorPunto);
public:
        Poligono(QList<Punto> listaPuntos);
        ~Poligono();
        void agregar(Punto aAgregar);
        int sizePoligono();
        double calcularArea();
        double calcularPerimetro();
        void triangulacion(double ** & matrizCosto,double ** & matrizK,double & valor);
        void trazarLineas(QList<Punto> &lineas,int &s, int &k, int &i, double **matrizK);
        QList<Punto> convexHull();
};

#endif // POLIGONO_H
