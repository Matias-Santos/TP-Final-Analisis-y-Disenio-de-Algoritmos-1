#ifndef VENTANATRASLADAR_H
#define VENTANATRASLADAR_H

#include <QDialog>

namespace Ui {
class VentanaTrasladar;
}

class VentanaTrasladar : public QDialog
{
    Q_OBJECT

public:
    explicit VentanaTrasladar(QWidget *parent = nullptr);
    ~VentanaTrasladar();

private slots:

    void on_ok_clicked();

    void on_cancelar_clicked();

signals:
   void apretoOK(double x,double y);

private:
    Ui::VentanaTrasladar *ui;
};

#endif // VENTANATRASLADAR_H
