#include "poligono.h"
#include "poligono.h"
#include <QDebug>

//---------------------Metodos privados-------------------
void Poligono::agregarPrivado(Punto aAgregar)
{
    listaPol.push_back(aAgregar);
}

//Metodo para crear la matriz O(n) siendo n la cantidad de filas
void Poligono::crearMatriz(double ** & matriz, int columna, int fila)
{
    matriz = new double*[fila];
    for (int f = 0; f <= fila; f++)
        matriz[f] = new double[columna];
}

//Metodo para preCargar la matriz O(n^m) siendo n la cantidad de filas y m la cantidad de columnas
void Poligono::preCargaMatriz(double ** & matriz, int columna, int fila)
{
    for(int i=0; i<=fila; i++)
        for(int j=0; j<columna; j++)
                matriz[i][j]= 0;
}

//Metodo para trazar las lineas del poligono
void Poligono::trazarLineas(QList<Punto> & lineas,int & s, int & k, int & i,double ** matrizK)
    {
        //calculo el nuevo k
        k=matrizK[s][i];

        //calculo los vertices a agregar;
        if(((i+1)!=(i+k))&&((i-1)!=(i+k)))
        {
            lineas.push_back(listaPol.at(i));
            lineas.push_back(listaPol.at(i+k));
        }
        if(((i+s-1)!=(i+k+1))&&((i+s-1)!=(i+k-1)))
        {
            lineas.push_back(listaPol.at(i+k));
            lineas.push_back(listaPol.at(i+s-1));
        }

        //llamo a las nuevas sol
        if(matrizK[k+1][i]!=0)
        {
            s=k+1;
            trazarLineas(lineas,s,k,i,matrizK);
        }
        if(matrizK[s-k][i+k]!=0)
        {
            s=s-k;
            i=i+k;
            trazarLineas(lineas,s,k,i,matrizK);
        }
    }

//---------------------Metodos publicos--------------------

//Metodo constructor de la clase O(n)
Poligono::Poligono(QList<Punto> listaPuntos)
{
    QList<Punto>::iterator it;
    for(it=listaPuntos.begin();it< listaPuntos.end();it++)
        listaPol.push_front(*it);
}

//Metodo destructor de la clase O(n)
Poligono::~Poligono()
{
    listaPol.clear();
}

//Metodo agregar publico que se encarga de llamar al privado O(1)
void Poligono::agregar(Punto aAgregar)
{
    agregarPrivado(aAgregar);
}

//Metodo que retorna el tamaño del poligono O(1)
int Poligono::sizePoligono()
{
    return listaPol.size();
}

//Metodo para calcular el area de un poligono O(n)
double Poligono::calcularArea()
{
    double area=0.0;
    QList<Punto>:: iterator itp=listaPol.begin();
    Punto inic= *itp;
    for (int i=0; i<listaPol.size()-1; i++)
    {
        Punto a=*itp;
        itp++;
        Punto b=*itp;
        area+=a.distancia(b);
    }
    Punto fin = *itp;
    area+=inic.distancia(fin);
    if(area < 0)
        return area*(-0.5);
    else
        return area*(0.5);
}

//Metodo para calcular el perimetro de un poligono O(n)
double Poligono::calcularPerimetro()
{
    double perimetro=0.0;
    QList<Punto>:: iterator itp=listaPol.begin();
    Punto inic= *itp;
    for (int i=0; i<listaPol.size()-1; i++)
    {
        Punto a=*itp;
        itp++;
        Punto b=*itp;
        perimetro+=a.distancia(b);
    }
    Punto fin = *itp;
    perimetro+=inic.distancia(fin);
    return perimetro;
}

//Metodo para calcular la triangulacion O(n^3)
void Poligono::triangulacion(double ** & matrizCosto,double ** & matrizK,double & costo)
{
    int tam = listaPol.size();
    if(tam<4)
        costo=0;
    //Pasaje de QLista a vector
    QVector<Punto> vectorPuntos;
    for(int i=0; i<listaPol.size();i++)
        vectorPuntos.push_back(listaPol.at(i));
        //Inicializacion de la matriz
    crearMatriz(matrizCosto,tam,tam);
    preCargaMatriz(matrizCosto,tam,tam);
    crearMatriz(matrizK,tam,tam);
    preCargaMatriz(matrizK,tam,tam);

    //Algoritmo
    for(int s=4; s<=tam; s++)
        for(int i=0; i<tam; i++)
            for(int k=1; k<=s-2; k++)
            {
                Punto a,b,c;
                a=vectorPuntos[i];
                double valorMat1,valorMat2,aux=0;
                if(i+k > tam-1)
                {
                    b=vectorPuntos[i+k-tam];
                    valorMat1=(matrizCosto[k+1][i]);
                    valorMat2=(matrizCosto[s-k][i+k-tam]);
                }
                else
                {
                    b=vectorPuntos[i+k];
                    valorMat1=(matrizCosto[k+1][i]);
                    valorMat2=(matrizCosto[s-k][i+k]);
                }
                if(i+s-1 > tam-1)
                    c=vectorPuntos[i+s-1-tam];
                else
                    c=vectorPuntos[i+s-1];
                if ((i+1==i+k)||(i-1==i+k))
                    aux = valorMat1 + valorMat2 + b.distancia(c);
                else if(((i+k+1)==(i+s-1))||((i+k-1)==(i+s-1)))
                    aux = valorMat1 + valorMat2 + a.distancia(b);
                else
                    aux= valorMat1 + valorMat2 + a.distancia(b) + b.distancia(c);
                if((matrizCosto[s][i]>= aux)||(matrizCosto[s][i]==0))
                {
                    matrizCosto[s][i]=aux;
                    matrizK[s][i]=k;
                }
            }
    costo= matrizCosto[tam][0];
}

void Poligono::buscarMayorYMenorY(Punto& mayorY,Punto& menorY)
{
    QList<Punto>::iterator itL=listaPol.begin();
    while (itL!=listaPol.end())
    {
        Punto aux=*itL;
        if ((aux.getY()) < (menorY.getY()))
            menorY=aux;
        else
            if((aux.getY() == menorY.getY()) && (aux.getX() < menorY.getX()))
                menorY=aux;
        if ((aux.getY()) > (mayorY.getY()))
            mayorY=aux;
        else
            if((aux.getY() == menorY.getY()) && (aux.getX() > menorY.getX()))
                mayorY=aux;
        itL++;
    }
}

void Poligono::inicializarPuntos(Punto& p1,Punto& p2, const Punto& puntoActual)
{
    //Inicializacion de los primeros 2 puntos
    QList<Punto>::iterator itL=listaPol.begin();
    p1=*itL;
    itL++;
    p2=*itL;
    if (p1==puntoActual)
    {
        itL++;
        p1=*itL;
    }
    else
        if (p2==puntoActual)
        {
            itL++;
            p1=*itL;
        }
}
void Poligono::calcularMejorPuntoMenor(const Punto& puntoActual, const Punto& p1, const Punto& p2, Punto& mejorPunto)
{
    if (p1!=p2)
    {
        Punto vector1=p1;
        Punto vector2=p2;
        vector1 = vector1 - puntoActual;
        vector2 = vector2 - puntoActual;
        if ((vector1.productoCruzado(vector2)) > 0)
            mejorPunto = p1;
        else
        {
            if ((vector1.productoCruzado(vector2)) < 0)
                mejorPunto = p2;
            else
            {
               if ((vector1.getY()) > (vector2.getY())) ///Toma el punto que este mas lejos del punto vertice
                    mejorPunto=p1;
                else
                    mejorPunto=p2;
            }
        }
    }
    else
        mejorPunto=p1;
}

void Poligono::calcularMejorPuntoMayor(const Punto& puntoActual, const Punto& p1, const Punto& p2, Punto& mejorPunto)
{
    if (p1!=p2)
    {
        Punto vector1=p1;
        Punto vector2=p2;
        vector1 = vector1 - puntoActual;
        vector2 = vector2 - puntoActual;
        if ((vector1.productoCruzado(vector2)) > 0)
            mejorPunto = p1;
        else
        {
            if ((vector1.productoCruzado(vector2)) < 0)
                mejorPunto = p2;
            else
            {
               if ((vector1.getY()) < (vector2.getY())) ///Toma el punto que este mas lejos del punto vertice
                    mejorPunto=p1;
                else
                    mejorPunto=p2;
            }
        }
    }
    else
        mejorPunto=p1;
}

QList<Punto> Poligono::convexHull()
{
    Punto mayorY=listaPol.front();
    Punto menorY=listaPol.front();
    buscarMayorYMenorY(mayorY,menorY);
    QList<Punto> convexhull;
    Punto mejorPunto;
    Punto puntActual=menorY;

    //Inicializacion de los primeros 2 puntos
    Punto p1;
    Punto p2;
    inicializarPuntos(p1, p2, puntActual);

    ///Analisis de productos Punto hasta el maximo Punto
    //Busqueda de todos los puntos de menor angulo
    QList<Punto>:: iterator itL=listaPol.begin();
    while (puntActual!=mayorY)
    {
        itL=listaPol.begin();
        while (itL!=listaPol.end())
        {
            calcularMejorPuntoMenor(puntActual, p1,p2, mejorPunto);
            //Hago que p1 sea siempre el Punto que tiene menor angulo con el eje
            p1=mejorPunto;
            p2=*itL;
            itL++;
        }
        puntActual=p1;
        convexhull.push_front(p1);
    }

    ///Analisis de productos Punto hasta el minimo Punto
    while (puntActual!=menorY)
    {
        itL=listaPol.begin();
        while (itL!=listaPol.end())
        {
            calcularMejorPuntoMayor(puntActual, p1, p2, mejorPunto);
            //Hago que p1 sea siempre el Punto que tiene menor angulo con el eje
            p1=mejorPunto;
            p2=*itL;
            itL++;
        }
        puntActual=p1;
        convexhull.push_front(p1);
    }
    return convexhull;
}

/*
int Poligono::orientation(Punto p, Punto q, Punto r)
{
    int val = (q.getY() - p.getY()) * (r.getX() - q.getX()) -
              (q.getX() - p.getX()) * (r.getY() - q.getY());

    if (val == 0) return 0;  // colinear
    return (val > 0)? 1: 2; // clock or counterclock wise
}

int Poligono::distSq(Punto p1, Punto p2)
{
    return (p1.getX() - p2.getX())*(p1.getX() - p2.getX()) +
          (p1.getY() - p2.getY())*(p1.getY() - p2.getY());
}
int Poligono::compare(const void *vp1, const void *vp2)
{
   Punto *p1 = (Punto *)vp1;
   Punto *p2 = (Punto *)vp2;

   // Find orientation
   int o = orientation(p0, *p1, *p2);
   if (o == 0)
     return (distSq(p0, *p2) >= distSq(p0, *p1))? -1 : 1;
   return (o == 2)? -1: 1;
}

QList<Punto> Poligono::convexHull()
{
    QList<Punto> listaConvex;
    int menor=0;

    //Busco el punto mas abajo y a la izquierda
    for (int i=0; i<listaPol.size();i++)
    {
        if(listaPol.at(i).getY() < listaPol.at(menor).getY())
            menor=i;
        else
            if((listaPol.at(i).getY() == listaPol.at(menor).getY()) && (listaPol.at(i).getX() < listaPol.at(menor).getX()))
                menor=i;
    }
    //Intercambio el punto elegido con el primero de la lista
    Punto aux=listaPol.at(menor);
    listaPol.replace(menor,listaPol.front());
    listaPol.replace(0,aux);
    p0 = listaPol.at(0);

    for (int i=0; i<listaPol.size();i++)
    {

    }
    return listaConvex;
}
*/







