#include "ventanatriangulacion.h"
#include "ui_ventanatriangulacion.h"
#include <QtDebug>

ventanaTriangulacion::ventanaTriangulacion(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::ventanaTriangulacion)
{
    ui->setupUi(this);
    ui->costoMinimo->setText("  ");
}

ventanaTriangulacion::~ventanaTriangulacion()
{
    delete ui;
}

void ventanaTriangulacion::imprimeCosto(double aux)
{
   ui->costoMinimo->setText("Costo minimo de la triangulacion: " + QString::number(aux));
}

void ventanaTriangulacion::inicializaMatrizCosto(int n)
{
    ui->MatrizCosto->setColumnCount(n);
    ui->MatrizCosto->setRowCount(n-2);
    QStringList titulosCol;
    QStringList titulosFil;
    for(int f=0; f<n; f++)
        for(int c=0; c<n; c++)
        {
            QString indiceI= QString::number(c);
            QString indiceS=QString::number(n-c);
            titulosFil.push_back("s= " + indiceS);
            titulosCol.push_back("i= " + indiceI);
            QTableWidgetItem * item = new QTableWidgetItem("0");
            item->setFlags(item->flags() ^ (Qt::ItemIsSelectable|Qt::ItemIsEditable));
            ui->MatrizCosto->setItem(f,c,item);
        }
   ui->MatrizCosto->setHorizontalHeaderLabels(titulosCol);
   ui->MatrizCosto->setVerticalHeaderLabels(titulosFil);
}

void ventanaTriangulacion::inicializaMatrizK(int n)
{
    ui->MatrizK->setColumnCount(n);
    ui->MatrizK->setRowCount(n-2);
    QStringList titulosCol;
    QStringList titulosFil;
    for(int f=0; f<n; f++)
        for(int c=0; c<n; c++)
        {
            QString indiceI= QString::number(c);
            QString indiceS=QString::number(n-c);
            titulosFil.push_back("s= " + indiceS);
            titulosCol.push_back("i= " + indiceI);
            QTableWidgetItem * item = new QTableWidgetItem("0");
            item->setFlags(item->flags() ^ (Qt::ItemIsSelectable|Qt::ItemIsEditable));
            ui->MatrizK->setItem(f,c,item);
        }
   ui->MatrizK->setHorizontalHeaderLabels(titulosCol);
   ui->MatrizK->setVerticalHeaderLabels(titulosFil);
}

void ventanaTriangulacion::mostrarMatrizCosto(double ** & matriz,int n)
{
    inicializaMatrizCosto(n);
    double aux= matriz[n][0];
    QString valor= QString::number(aux);
    QTableWidgetItem *item = new QTableWidgetItem(valor);
    ui->MatrizCosto->setItem(0,0,item);
    int j=1;
    for (int f = n-1; f > 2; f--)
    {
        for(int c=0; c< n ; c++)
        {
            aux= matriz[f][c];
            QString valor= QString::number(aux);
            QTableWidgetItem *item = new QTableWidgetItem(valor);
            item->setFlags(item->flags() ^ (Qt::ItemIsSelectable|Qt::ItemIsEditable));
            ui->MatrizCosto->setItem(j,c,item);
        }
        j++;
   }
    QHeaderView * headerHorizontal= ui->MatrizCosto->horizontalHeader();
    QHeaderView * headerVertical= ui->MatrizCosto->verticalHeader();
    headerHorizontal->setSectionResizeMode(QHeaderView::Stretch);
    headerVertical->setSectionResizeMode(QHeaderView::Stretch);
}

void ventanaTriangulacion::mostrarMatrizK(double ** & matriz,int n)
{
    inicializaMatrizK(n);
    double aux= matriz[n][0];
    QString valor= QString::number(aux);
    QTableWidgetItem *item = new QTableWidgetItem(valor);
    ui->MatrizK->setItem(0,0,item);
    int j=1;
    for (int f = n-1; f > 2; f--)
    {
        for(int c=0; c < n ; c++)
        {
            aux= matriz[f][c];
            QString valor= QString::number(aux);
            QTableWidgetItem *item = new QTableWidgetItem(valor);
            item->setFlags(item->flags() ^ (Qt::ItemIsSelectable|Qt::ItemIsEditable));
            ui->MatrizK->setItem(j,c,item);
        }
        j++;
    }
    QHeaderView * headerHorizontal= ui->MatrizK->horizontalHeader();
    QHeaderView * headerVertical= ui->MatrizK->verticalHeader();
    headerHorizontal->setSectionResizeMode(QHeaderView::Stretch);
    headerVertical->setSectionResizeMode(QHeaderView::Stretch);
}
