#ifndef PUNTO_H
#define PUNTO_H

class Punto
{
    public:
        Punto(){};
        Punto(const Punto & aux);
        Punto(const double &x, const double &y);
        void setX(const double &x);
        void setY(const double &y);
        double getX()const;
        double getY()const;
        double distancia(const Punto &aux)const;
        double productoCruzado(const Punto &aux)const;
        //Operadores
        Punto operator-(const Punto & aux);
        void operator*(const double & i);
        void operator=(const Punto & aux);
        bool operator==(const Punto &aux)const;
        bool operator!=(const Punto &aux)const;
private:
        double x;
        double y;
};

#endif // PUNTO_H
