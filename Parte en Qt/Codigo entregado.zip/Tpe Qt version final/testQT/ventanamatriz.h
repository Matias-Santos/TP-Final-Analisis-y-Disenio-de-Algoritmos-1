#ifndef VENTANAMATRIZ_H
#define VENTANAMATRIZ_H

#include <QWidget>

namespace Ui {
class ventanaMatriz;
}

class ventanaMatriz : public QWidget
{
    Q_OBJECT

public:
    explicit ventanaMatriz(QWidget *parent = nullptr);
    ~ventanaMatriz();

private:
    Ui::ventanaMatriz *ui;
};

#endif // VENTANAMATRIZ_H
