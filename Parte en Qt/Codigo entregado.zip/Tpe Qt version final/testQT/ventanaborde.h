#ifndef VENTANABORDE_H
#define VENTANABORDE_H
#include <QPen>
#include <QDialog>

namespace Ui {
class VentanaBorde;
}

class VentanaBorde : public QDialog
{
    Q_OBJECT

public:
    explicit VentanaBorde(QWidget *parent = nullptr);

    ~VentanaBorde();

private slots:
    void on_sliderGrosor_valueChanged(int value);

    void on_spinBox_valueChanged(int valor);

    void on_Ok_clicked();

    void on_cancelar_clicked();

signals:
   void apretoOK(int valor);

private:
    Ui::VentanaBorde *ui;
};

#endif // VENTANABORDE_H
