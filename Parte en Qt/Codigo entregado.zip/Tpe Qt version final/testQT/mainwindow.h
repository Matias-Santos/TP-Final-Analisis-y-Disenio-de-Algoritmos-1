#ifndef MAINWINDOW_H
#define MAINWINDOW_H
#include <QColorDialog>
#include <QDesktopServices>
#include <QGraphicsScene>
#include <QGraphicsView>
#include <QFileDialog>
#include <QPen>
#include <QTextStream>
#include <QUrl>

#include <QMainWindow>

#include "punto.h"
#include "poligono.h"
#include "ventanaerror.h"
#include "ventanatriangulacion.h"
#include "ventanatrasladar.h"
#include "ventanaborde.h"

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);

    ~MainWindow();
private:
    Ui::MainWindow *ui;
    QGraphicsScene * scene;
    QPen penCuerdas,penEjes,penPol,penPuntos;
    QList<Punto> listaCuerdas,listaGrafico,listaPoligono;
    ventanaTriangulacion * vTriangulacion;
    VentanaError * vError;
    VentanaBorde * vGrosor;
    VentanaTrasladar * vTrasladar;
    double factorDeCorreccion,radio;
    bool graficado,esConvexo,triangulado;

    //Metodos privados
    Punto promedio();
    void cargarEnListWidget();
    void deTextoALista(const QString & textocrudo);
    void graficarEjes();
    void graficar();
    void trazarCuerdas();

private slots:
    //Funciones utilizadas por señales
    void modificarGrosor(int valor);
    void trasladar(double x, double y);

    //Interfaz
    void mousePressEvent(QMouseEvent *event);
    void on_buttonAgregar_clicked();
    void on_buttonEliminar_clicked();
    void on_buttonGraficar_clicked();
    void on_buttonAgrandar_clicked();
    void on_buttonAchicar_clicked();

    //Opciones
    void on_actionNuevo_triggered();
    void on_actionCargar_triggered();
    void on_actionGuardar_triggered();
    void on_actionInstrucciones_triggered();
    void on_actionSalir_triggered();

    //Editar
    void on_actionColorLineas_triggered();
    void on_actionColorVertices_triggered();
    void on_actionBorde_triggered();
    void on_actionTrasladar_triggered();
    void on_actionTransformarAConvexo_triggered();

    //Calculos
    void on_actionArea_triggered();
    void on_actionPerimetro_triggered();
    void on_actionTriangulacionMinima_triggered();
};
#endif // MAINWINDOW_H
